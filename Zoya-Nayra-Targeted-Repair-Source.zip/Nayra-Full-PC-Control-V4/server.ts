import "dotenv/config";
import express from "express";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { GoogleGenAI, Type } from "@google/genai";

const execFileAsync = promisify(execFile);
const app = express();
app.use(express.json({ limit: "2mb" }));
app.use((req,res,next)=>{
  const origin=req.headers.origin;
  if(origin && !/^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin)) return res.status(403).json({ok:false,message:"Local access only"});
  if(origin)res.setHeader("Access-Control-Allow-Origin",origin);
  res.setHeader("Access-Control-Allow-Headers","Content-Type");res.setHeader("Access-Control-Allow-Methods","GET,POST,OPTIONS");
  if(req.method==="OPTIONS")return res.sendStatus(204);next();
});

const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
const ps=async(script:string)=>execFileAsync("powershell.exe",["-NoProfile","-ExecutionPolicy","Bypass","-Command",script],{windowsHide:true,maxBuffer:16*1024*1024});
const HOME=os.homedir();
const DESKTOP=path.join(HOME,"Desktop");
const DOCUMENTS=path.join(HOME,"Documents");
const DOWNLOADS=path.join(HOME,"Downloads");
const DATA=path.join(HOME,".nayra");
const REMINDERS=path.join(DATA,"reminders.json");
const MEMORY=path.join(DATA,"memory.json");
const WORKSPACE=path.join(DESKTOP,"Nayra Workspace");
const BROWSERS=["chrome","msedge","brave","opera","opera_gx","firefox"];

function q(s:string){return s.replace(/'/g,"''");}
// Choose a model the current API key can actually access; cache for this process.
let cachedTextModel: string | null = null;
async function getTextModel(ai: GoogleGenAI): Promise<string> {
  if (cachedTextModel) return cachedTextModel;
  const preferred = (process.env.GEMINI_TEXT_MODEL || "").replace(/^models\//, "");
  try {
    const listing = await ai.models.list({config:{pageSize:100}});
    const names: string[] = [];
    for await (const model of listing) {
      const name = String(model.name || "").replace(/^models\//, "");
      if (name && /gemini/i.test(name) && !/tts|live|image|embedding|robotics/i.test(name)) names.push(name);
    }
    const candidates = [preferred, "gemini-3-flash-preview", "gemini-2.5-flash", ...names].filter(Boolean);
    cachedTextModel = candidates.find(n => names.includes(n)) || names[0] || preferred || "gemini-3-flash-preview";
  } catch {
    cachedTextModel = preferred || "gemini-3-flash-preview";
  }
  return cachedTextModel;
}

async function init(){await fs.mkdir(DATA,{recursive:true});await fs.mkdir(WORKSPACE,{recursive:true});for(const f of [REMINDERS,MEMORY]){try{await fs.access(f)}catch{await fs.writeFile(f,"[]","utf8")}}}

// Reliable Win32 foreground focus + Unicode SendInput. This avoids flaky SendKeys/clipboard focus.
async function focusProcess(names:string[], wait=350){
  const list=names.map(n=>`'${q(n)}'`).join(",");
  const script=`$names=@(${list}); Add-Type @'\nusing System; using System.Text; using System.Runtime.InteropServices; public static class W { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h,int n); [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h); [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p); [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId(); [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool f); [DllImport("user32.dll")] public static extern bool AllowSetForegroundWindow(int p); }\n'@; $w=New-Object -ComObject WScript.Shell; foreach($n in $names){foreach($p in Get-Process -Name $n -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowHandle -ne 0}){try{$h=$p.MainWindowHandle; $fg=[W]::GetForegroundWindow(); $t=[W]::GetWindowThreadProcessId($fg,[ref]$pid); $c=[W]::GetCurrentThreadId(); if($t -and $t -ne $c){[W]::AttachThreadInput($t,$c,$true)|Out-Null}; [W]::ShowWindowAsync($h,9)|Out-Null; [W]::BringWindowToTop($h)|Out-Null; [W]::SetForegroundWindow($h)|Out-Null; if($t -and $t -ne $c){[W]::AttachThreadInput($t,$c,$false)|Out-Null}; $w.AppActivate($p.Id)|Out-Null; Write-Output $p.Id; exit 0}catch{}}}; exit 1`;
  try{await ps(script);await sleep(wait);return true}catch{return false}
}
async function foregroundTitle(){try{const {stdout}=await ps(`Add-Type @'\nusing System; using System.Text; using System.Runtime.InteropServices; public static class T { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h,StringBuilder s,int n); }\n'@; $b=New-Object System.Text.StringBuilder 1024; [T]::GetWindowText([T]::GetForegroundWindow(),$b,1024)|Out-Null; $b.ToString()`);return stdout.trim()}catch{return ""}}

async function sendInputText(text:string){
  const b64=Buffer.from(text,"utf8").toString("base64");
  const script=`$text=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64}')); Add-Type @'\nusing System; using System.Runtime.InteropServices; public static class I { [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public KEYBDINPUT ki; } [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; } [DllImport("user32.dll",SetLastError=true)] public static extern uint SendInput(uint n, INPUT[] inputs,int size); const uint INPUT_KEYBOARD=1, KEYEVENTF_UNICODE=4, KEYEVENTF_KEYUP=2; public static void Text(string s){foreach(char ch in s){if(ch=='\\n'||ch=='\\r'){Key(0x0D,0);continue;} var a=new INPUT[2]; a[0].type=INPUT_KEYBOARD; a[0].ki=new KEYBDINPUT{wVk=0,wScan=ch,dwFlags=KEYEVENTF_UNICODE,time=0,dwExtraInfo=UIntPtr.Zero}; a[1].type=INPUT_KEYBOARD; a[1].ki=new KEYBDINPUT{wVk=0,wScan=ch,dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP,time=0,dwExtraInfo=UIntPtr.Zero}; SendInput(2,a,Marshal.SizeOf(typeof(INPUT))); }} static void Key(ushort vk,ushort scan){var a=new INPUT[2];a[0].type=INPUT_KEYBOARD;a[0].ki=new KEYBDINPUT{wVk=vk,wScan=scan,dwFlags=0};a[1].type=INPUT_KEYBOARD;a[1].ki=new KEYBDINPUT{wVk=vk,wScan=scan,dwFlags=KEYEVENTF_KEYUP};SendInput(2,a,Marshal.SizeOf(typeof(INPUT)));}}\n'@; [I]::Text($text)`;
  await ps(script);
}
async function key(vk:number){await ps(`Add-Type @'\nusing System; using System.Runtime.InteropServices; public static class K { [DllImport("user32.dll")] public static extern void keybd_event(byte v,byte s,uint f,UIntPtr e); }\n'@; [K]::keybd_event(${vk},0,0,[UIntPtr]::Zero); [K]::keybd_event(${vk},0,2,[UIntPtr]::Zero)`)}
async function hotkey(vks:number[]){const down=vks.map(v=>`[K]::keybd_event(${v},0,0,[UIntPtr]::Zero);`).join("");const up=[...vks].reverse().map(v=>`[K]::keybd_event(${v},0,2,[UIntPtr]::Zero);`).join("");await ps(`Add-Type @'\nusing System; using System.Runtime.InteropServices; public static class K { [DllImport("user32.dll")] public static extern void keybd_event(byte v,byte s,uint f,UIntPtr e); }\n'@; ${down} Start-Sleep -Milliseconds 70; ${up}`)}

async function click(x:number,y:number,double=false){await ps(`Add-Type @'\nusing System; using System.Runtime.InteropServices; public static class M { [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y); [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint d,UIntPtr e); }\n'@; [M]::SetCursorPos(${Math.round(x)},${Math.round(y)})|Out-Null;Start-Sleep -Milliseconds 100;[M]::mouse_event(2,0,0,0,[UIntPtr]::Zero);[M]::mouse_event(4,0,0,0,[UIntPtr]::Zero);${double?'[M]::mouse_event(2,0,0,0,[UIntPtr]::Zero);[M]::mouse_event(4,0,0,0,[UIntPtr]::Zero);':''}`)}
async function scroll(amount:number){const a=Math.max(-10,Math.min(10,Math.trunc(amount)))*120;await ps(`Add-Type @'\nusing System; using System.Runtime.InteropServices; public static class M { [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint d,UIntPtr e); }\n'@;[M]::mouse_event(0x800,0,0,${a},[UIntPtr]::Zero)`)}

async function activateBrowser(){return focusProcess(BROWSERS,250)}
async function browserTabTitle(){return foregroundTitle()}

// Find an existing tab/window by cycling tabs. No new tab is created unless explicitly requested.
async function findExistingTab(keyword:string,maxTabs=20){
  if(!(await activateBrowser())) return false;
  const start=await browserTabTitle();
  for(let i=0;i<maxTabs;i++){
    const title=(await browserTabTitle()).toLowerCase();
    if(title.includes(keyword.toLowerCase())) return true;
    await hotkey([0x11,0x09]); await sleep(180); // Ctrl+Tab
    const now=await browserTabTitle();
    if(now===start && i>0) break;
  }
  return false;
}
async function currentTabNavigate(url:string){
  if(!(await activateBrowser())){await execFileAsync("cmd",["/c","start","",url],{windowsHide:true});await sleep(1200);return}
  await hotkey([0x11,0x4C]);await sleep(80);await sendInputText(url);await key(0x0D);await sleep(1000);
}
async function browserNavigate(url:string, preferredTab?:string){
  if(preferredTab && await findExistingTab(preferredTab)) { await currentTabNavigate(url); return; }
  await currentTabNavigate(url);
}

async function openApp(name:string){
  const c=name.toLowerCase().trim();
  if(c.includes("notepad")){if(!(await focusProcess(["notepad","notepad++"]))) {await execFileAsync("notepad.exe",[],{windowsHide:true});await sleep(900);await focusProcess(["notepad","notepad++"])}return "Notepad is open and focused."}
  if(c.includes("calculator")||c==="calc"){if(!(await focusProcess(["calculatorapp","calculator"])))await execFileAsync("calc.exe",[],{windowsHide:true});await sleep(700);await focusProcess(["calculatorapp","calculator"]);return "Calculator is open and focused."}
  if(c.includes("explorer")||c.includes("file explorer")){await execFileAsync("explorer.exe",[],{windowsHide:true});await sleep(700);return "File Explorer opened."}
  if(c.includes("vs code")||c.includes("vscode")||c.includes("visual studio code")){if(!(await focusProcess(["code"]))) {try{await execFileAsync("cmd",["/c","start","","code"],{windowsHide:true})}catch{} await sleep(1200);await focusProcess(["code"])}return "VS Code is open and focused."}
  const safe=q(name);
  const script=`$n='${safe}';$a=Get-StartApps|Where-Object{$_.Name -like "*$n*"}|Select-Object -First 1;if($a){Start-Process explorer.exe ("shell:AppsFolder\\"+$a.AppID)}else{throw "Application not found: $n"}`;
  await ps(script);await sleep(1200);return `${name} opened.`;
}

function clean(s:string){return s.replace(/[“”]/g,'"').replace(/[‘’]/g,"'").replace(/\s+/g," ").trim()}
function writeText(command:string){
  const pats=[
    /(?:aur|and)\s+(?:isme|is me|in it|there)\s+(.+?)\s+(?:likh(?:o|do|na|ane|dena)?(?:\s+ko)?(?:\s+bola)?|type(?:\s+kar(?:o|do)?)?)$/i,
    /(?:isme|is me|in it|there)\s+(.+?)\s+(?:likh(?:o|do|na|ane|dena)?(?:\s+ko)?(?:\s+bola)?|type(?:\s+kar(?:o|do)?)?)$/i,
    /(?:notepad|editor).*?(?:me|mein|in it)\s+(.+?)\s+(?:likh(?:o|do|na|ane|dena)?(?:\s+ko)?(?:\s+bola)?|type(?:\s+kar(?:o|do)?)?)$/i,
    /(?:likho|likh do|type karo|write|paste)\s*[:\-]?\s*(.+)$/i,
  ];for(const p of pats){const m=command.match(p);if(m?.[1])return m[1].trim()}return ""
}
async function writeToNotepad(text:string){if(!(await focusProcess(["notepad","notepad++"],250))){await execFileAsync("notepad.exe",[],{windowsHide:true});await sleep(1000);if(!(await focusProcess(["notepad","notepad++"],300)))throw new Error("Notepad opened but could not be focused.")}await sendInputText(text);return `Verified text input sent to Notepad: ${text}`}

function roots(){return [HOME,DESKTOP,DOCUMENTS,DOWNLOADS,WORKSPACE].map(x=>path.resolve(x).toLowerCase())}
function resolvePath(input:string){let s=input.trim().replace(/^['"]|['"]$/g,"").replace(/^~(?=\\|\/|$)/,HOME);if(/^desktop(\\|\/|$)/i.test(s))s=path.join(DESKTOP,s.replace(/^desktop[\\/]?/i,""));else if(/^documents(\\|\/|$)/i.test(s))s=path.join(DOCUMENTS,s.replace(/^documents[\\/]?/i,""));else if(/^downloads(\\|\/|$)/i.test(s))s=path.join(DOWNLOADS,s.replace(/^downloads[\\/]?/i,""));else if(!path.isAbsolute(s))s=path.join(WORKSPACE,s);const full=path.resolve(s);if(!roots().some(r=>full.toLowerCase()===r||full.toLowerCase().startsWith(r+path.sep)))throw new Error("For safety, file operations are limited to your Windows user folders.");return full}
async function folder(p:string){const f=resolvePath(p);await fs.mkdir(f,{recursive:true});await fs.access(f);return f}
async function file(p:string,c:string){const f=resolvePath(p);await fs.mkdir(path.dirname(f),{recursive:true});await fs.writeFile(f,c,"utf8");await fs.access(f);return f}

async function screenshot(){const f=path.join(DATA,`screen-${Date.now()}.png`);await ps(`Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing;$b=[System.Windows.Forms.SystemInformation]::VirtualScreen;$bmp=New-Object System.Drawing.Bitmap($b.Width,$b.Height);$g=[System.Drawing.Graphics]::FromImage($bmp);$g.CopyFromScreen($b.Left,$b.Top,0,0,$bmp.Size);$bmp.Save('${q(f)}',[System.Drawing.Imaging.ImageFormat]::Png);$g.Dispose();$bmp.Dispose()`);return f}
async function screenContext(){const f=await screenshot();const title=await foregroundTitle();let out=`Active window: ${title||"Unknown"}.`;if(process.env.GEMINI_API_KEY){try{const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});const data=await fs.readFile(f);const r=await ai.models.generateContent({model:await getTextModel(ai),contents:[{parts:[{text:"Inspect this Windows 11 screenshot. Identify visible apps, important controls, text and state. Do not invent. Be concise."},{inlineData:{mimeType:"image/png",data:data.toString("base64")}}]}]});out+=`\n${r.text||"No visual analysis."}`}catch{out+="\nScreen vision unavailable."}}try{await fs.unlink(f)}catch{}return out}

async function youtubeSearchPlay(query:string){
  const qv=clean(query).replace(/\b(youtube|you tube|par|pe|me|mein|song|gana|music|play|bajao|baja do|chalao|chala do)\b/ig," ").replace(/\s+/g," ").trim()||"Arijit Singh";
  // Prefer an already-open YouTube tab. If none exists, use current browser tab only if it is already a browser page; never create a tab.
  const found=await findExistingTab("youtube",20);
  if(!found){await currentTabNavigate(`https://www.youtube.com/results?search_query=${encodeURIComponent(qv)}`)}else{await currentTabNavigate(`https://www.youtube.com/results?search_query=${encodeURIComponent(qv)}`)}
  await sleep(1400);
  // Use YouTube keyboard search result selection: press Tab a bounded number of times and Enter, then K.
  // First try the page's first result via direct URL discovery from server-side HTML.
  let id:string|null=null;try{const {stdout}=await ps(`$u='https://www.youtube.com/results?search_query='+[uri]::EscapeDataString('${q(qv)}');$h=(Invoke-WebRequest -UseBasicParsing -Uri $u -Headers @{'User-Agent'='Mozilla/5.0'}).Content;$m=[regex]::Matches($h,'"videoId":"([A-Za-z0-9_-]{11})"');foreach($x in $m){if($x.Groups[1].Value){Write-Output $x.Groups[1].Value;break}}`);id=stdout.trim().split(/\r?\n/).find(x=>/^[A-Za-z0-9_-]{11}$/.test(x.trim()))||null}catch{}
  if(id){await currentTabNavigate(`https://www.youtube.com/watch?v=${id}`);await sleep(1800);await key(0x4B);return `Playing ${qv} on the existing YouTube tab.`}
  // fallback UI: first result selection
  await hotkey([0x09]);await sleep(250);for(let i=0;i<8;i++){await key(0x09);await sleep(100)}await key(0x0D);await sleep(1500);await key(0x4B);return `YouTube playback command sent on the existing browser tab.`
}
async function youtubeToggle(){if(!(await findExistingTab("youtube",20)))throw new Error("No existing YouTube tab was found. Open YouTube once, then ask me to play/pause/stop.");await key(0x4B);return "YouTube playback toggled on the existing YouTube tab."}
async function youtubeStop(){return youtubeToggle()}

async function media(){await key(0xB3);return "Media playback toggled."}
async function lock(){await execFileAsync("rundll32.exe",["user32.dll,LockWorkStation"],{windowsHide:true});return "PC locked. Windows sign-in security remains enabled."}
async function wake(){await key(0x20);return "Wake signal sent. Windows may still require your normal sign-in."}

interface Reminder{id:string;text:string;dueAt:string;delivered?:boolean}
async function reminders():Promise<Reminder[]>{try{return JSON.parse(await fs.readFile(REMINDERS,"utf8"))}catch{return[]}}
async function saveReminders(x:Reminder[]){await fs.writeFile(REMINDERS,JSON.stringify(x,null,2),"utf8")}
async function addReminder(text:string,dueAt:string){const x=await reminders();const r={id:crypto.randomUUID(),text,dueAt,delivered:false};x.push(r);await saveReminders(x);return r}
function parseReminder(c:string){if(!/(remind|reminder|yaad|yaad dila)/i.test(c))return null;const m=c.match(/(?:at|@|baje)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);const now=new Date();const d=new Date(now);if(/\b(kal|tomorrow)\b/i.test(c))d.setDate(d.getDate()+1);if(m){let h=+m[1],min=+(m[2]||0);const ap=m[3]?.toLowerCase();if(ap==='pm'&&h<12)h+=12;if(ap==='am'&&h===12)h=0;d.setHours(h,min,0,0);if(d<=now&&!/\b(kal|tomorrow)\b/i.test(c))d.setDate(d.getDate()+1)}else if(/\b(kal|tomorrow)\b/i.test(c))d.setHours(9,0,0,0);else return null;let text=c.replace(/.*?(?:remind me|yaad dila(?: dena)?|reminder)\s*(?:ki|that|to)?/i,"").replace(/\s+(?:at|@|baje)\s*\d{1,2}(?::\d{2})?\s*(?:am|pm)?/i,"").replace(/\s+(?:kal|tomorrow)$/i,"").trim()||"Your reminder";return{text,dueAt:d.toISOString()}}
async function reminderLoop(){setInterval(async()=>{const x=await reminders(),now=Date.now();let changed=false;for(const r of x){if(!r.delivered&&new Date(r.dueAt).getTime()<=now){r.delivered=true;changed=true;try{await ps(`Add-Type -AssemblyName PresentationFramework;[System.Windows.MessageBox]::Show('${q(r.text)}','Zoya Reminder')|Out-Null`)}catch{}}}if(changed)await saveReminders(x)},5000)}

async function memoryRead():Promise<string[]>{try{return JSON.parse(await fs.readFile(MEMORY,"utf8"))}catch{return[]}}
async function memoryAdd(text:string){const m=await memoryRead();m.push(text.trim());await fs.writeFile(MEMORY,JSON.stringify(m.slice(-100),null,2),"utf8");return text.trim()}

async function aiPlan(command:string){if(!process.env.GEMINI_API_KEY)return null;const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});const r=await ai.models.generateContent({model:await getTextModel(ai),config:{responseMimeType:"application/json",responseSchema:{type:Type.OBJECT,properties:{action:{type:Type.STRING},app:{type:Type.STRING},text:{type:Type.STRING},path:{type:Type.STRING},content:{type:Type.STRING},query:{type:Type.STRING},target:{type:Type.STRING},url:{type:Type.STRING},dueAt:{type:Type.STRING},keys:{type:Type.ARRAY,items:{type:Type.STRING}}},required:["action"]}},contents:`You are the action planner for Zoya, a Windows 11 desktop agent. Understand Hindi, Roman Hindi and English. Output exactly one action from: OPEN_APP, TYPE_TEXT, CREATE_FILE, CREATE_FOLDER, OPEN_PATH, BROWSER_NAVIGATE, SEARCH_WEB, YOUTUBE_PLAY, YOUTUBE_PAUSE, YOUTUBE_STOP, WHATSAPP_OPEN, WHATSAPP_MESSAGE, PRINT, REMINDER, SCREEN_CONTEXT, LOCK, RESTART, SHUTDOWN, CANCEL_SHUTDOWN, WAKE_SCREEN, MEDIA_PLAY_PAUSE, COMPUTER_TASK, REMEMBER, NONE. Preserve exact names/text. If a task requires interacting inside an app, choose COMPUTER_TASK. Never use browser navigation for a desktop app. For YouTube play/pause/stop use dedicated actions. Command: ${command}`});try{return JSON.parse(r.text||"{}")}catch{return null}}

async function computerTask(goal:string):Promise<string>{if(!process.env.GEMINI_API_KEY)throw new Error("General computer control needs GEMINI_API_KEY in .env.");const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});let last="";for(let i=0;i<12;i++){const f=await screenshot();const data=await fs.readFile(f);const r=await ai.models.generateContent({model:await getTextModel(ai),config:{responseMimeType:"application/json",responseSchema:{type:Type.OBJECT,properties:{action:{type:Type.STRING},x:{type:Type.NUMBER},y:{type:Type.NUMBER},text:{type:Type.STRING},key:{type:Type.STRING},keys:{type:Type.ARRAY,items:{type:Type.STRING}},amount:{type:Type.NUMBER},app:{type:Type.STRING},url:{type:Type.STRING},reason:{type:Type.STRING}},required:["action"]}},contents:[{parts:[{text:`You control Windows 11 using one action at a time. Goal: ${goal}\nPrevious action: ${last}\nActive window: ${await foregroundTitle()}\nChoose one: click,double_click,type,key,hotkey,scroll,wait,open_app,navigate,done,fail. Do not create a new browser tab unless explicitly requested. Prefer existing windows and tabs. For typing, use type. Do not claim done unless the screenshot proves it.`},{inlineData:{mimeType:"image/png",data:data.toString("base64")}}]}]});try{await fs.unlink(f)}catch{}let p:any;try{p=JSON.parse(r.text||"{}")}catch{throw new Error("Computer planner returned invalid data.")}const a=String(p.action||"fail").toLowerCase();if(a==='done')return `Completed: ${goal}`;if(a==='fail')throw new Error(p.reason||`Could not complete: ${goal}`);if(a==='wait'){await sleep(Math.min(5000,Math.max(300,+p.amount||800)));last='wait';continue}if(a==='open_app'){await openApp(String(p.app||""));last='opened app';continue}if(a==='navigate'){await browserNavigate(String(p.url||""));last='navigated';continue}if(a==='type'){await sendInputText(String(p.text||""));last='typed';continue}if(a==='key'){const map:any={ENTER:13,TAB:9,ESC:27,SPACE:32,BACKSPACE:8,DELETE:46,UP:38,DOWN:40,LEFT:37,RIGHT:39,F5:116,F11:122};const k=String(p.key||'ENTER').toUpperCase();await key(map[k]||k.charCodeAt(0));last=`key ${k}`;continue}if(a==='hotkey'){const map:any={CTRL:17,ALT:18,SHIFT:16,WIN:91,ENTER:13,TAB:9};const ks=(p.keys||[]).map((x:string)=>map[x.toUpperCase()]||x.toUpperCase().charCodeAt(0));await hotkey(ks);last='hotkey';continue}if(a==='scroll'){await scroll(+p.amount||-3);last='scroll';continue}if(a==='click'||a==='double_click'){await click(+p.x,+p.y,a==='double_click');last=a;continue}throw new Error(`Unsupported computer action: ${a}`)}throw new Error(`Computer task timed out before verification: ${goal}`)}

async function whatsapp(target:string,message:string){const t=clean(target),m=clean(message);if(/^\+?\d[\d\s-]{7,}$/.test(t)){const phone=t.replace(/\D/g,"");await browserNavigate(`https://web.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(m)}`,"WhatsApp");await sleep(1800);return `WhatsApp chat opened for ${phone}; message prepared.`}await browserNavigate("https://web.whatsapp.com","WhatsApp");await sleep(2500);return computerTask(`In the currently open WhatsApp Web tab, search for contact ${t}, open the chat, type exactly this message: ${m}, and send it. Do not open a new browser tab.`)}

async function generateWebsite(command:string){if(!process.env.GEMINI_API_KEY)throw new Error("GEMINI_API_KEY is missing. Add it to .env for AI website generation.");const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});const r=await ai.models.generateContent({model:await getTextModel(ai),config:{responseMimeType:"application/json",responseSchema:{type:Type.OBJECT,properties:{projectName:{type:Type.STRING},files:{type:Type.ARRAY,items:{type:Type.OBJECT,properties:{path:{type:Type.STRING},content:{type:Type.STRING}},required:["path","content"]}}},required:["projectName","files"]}},contents:`Act as a senior frontend developer. Build the website requested below. Use plain HTML/CSS/JS unless a different stack is explicitly requested. Return complete runnable files, no API keys. User request: ${command}`});const d=JSON.parse(r.text||"{}");const name=String(d.projectName||"Nayra Website").replace(/[^\w -]/g,"_").trim()||"Nayra Website";const root=resolvePath(path.join("Desktop",name));await fs.mkdir(root,{recursive:true});for(const f of (Array.isArray(d.files)?d.files:[]).slice(0,80)){const rel=String(f.path||"").replace(/^[/\\]+/,"");if(!rel||rel.includes(".."))continue;const full=path.resolve(root,rel);if(!full.toLowerCase().startsWith(root.toLowerCase()+path.sep))continue;await fs.mkdir(path.dirname(full),{recursive:true});await fs.writeFile(full,String(f.content||""),"utf8")}const index=path.join(root,"index.html");await fs.access(index);try{await execFileAsync("cmd",["/c","start","","code",root],{windowsHide:true})}catch{}await sleep(900);await browserNavigate(`file://${index.replace(/\\/g,"/")}`);return `Website created and verified at ${root}. VS Code and preview opened.`}

function normalizeSpokenCommand(input:string):string {
  let c=clean(input).replace(/^(?:hey\s+)?(?:zoya|zoeya|nayra|nयरा|नायरा|जोया)[,\s:!-]*/i, "").trim();
  const hindiApps: Record<string,string>={"नोटपैड":"notepad","कैलकुलेटर":"calculator","क्रोम":"chrome","गूगल क्रोम":"chrome","पेंट":"paint","फाइल एक्सप्लोरर":"file explorer","यूट्यूब":"youtube","व्हाट्सएप":"whatsapp","वीएस कोड":"vs code"};
  for (const [h,en] of Object.entries(hindiApps)) c=c.replaceAll(h,en);
  c=c.replace(/(?:खोलो|खोल दो|खोलिए|ओपन करो|चालू करो|खोलना है)/g,"open");
  c=c.replace(/(?:में|पर)\s+/g," in ");
  // Natural Hindi puts the verb after the app: "notepad open".
  const m=c.match(/^(.+?)\s+(?:open|kholo|khol do|launch|start)\s*$/i);
  if(m)c=`open ${m[1]}`;
  return clean(c);
}
async function execute(command:string):Promise<string>{const c=normalizeSpokenCommand(command),l=c.toLowerCase();if(!c)throw new Error("Empty command.");
  if(/\b(?:chrome|google chrome|edge|microsoft edge|firefox)\b/i.test(c)&&/\b(?:open|khol|kholo|launch|start)\b/i.test(c)&&!/youtube|whatsapp|http|www\./i.test(c)){
    const browser=/edge/i.test(c)?"msedge":/firefox/i.test(c)?"firefox":"chrome";
    if(!(await focusProcess([browser]))) {
      await ps(`Start-Process '${browser}'`);await sleep(950);await focusProcess([browser]);
    }
    return `${browser} window focused.`;
  }
  if(/\byoutube\b/i.test(c)&&/\b(?:open|khol|kholo)\b/i.test(c)){
    await browserNavigate("https://www.youtube.com","youtube");return "YouTube opened in the current browser tab.";
  }

  if(/remember|yaad rakho|yaad rakhna|memory me save/i.test(l)){const text=c.replace(/.*?(remember|yaad rakho|yaad rakhna|memory me save)\s*/i,"").replace(/^that\s+/i,"");return `Memory saved: ${await memoryAdd(text)}`}
  if(/website|web site|webpage|web page/i.test(l)&&/bana|banao|create|build|make|develop|design|code/i.test(l))return generateWebsite(c);
  const rem=parseReminder(c);if(rem){const r=await addReminder(rem.text,rem.dueAt);return `Reminder saved for ${new Date(r.dueAt).toLocaleString()}: ${r.text}`}
  if(/cancel.*(shutdown|restart)|(shutdown|restart).*cancel/i.test(l)){await execFileAsync("shutdown",["/a"],{windowsHide:true});return "Pending shutdown/restart cancelled."}
  if(/\b(shutdown|shut down|pc band|computer band|computer off|pc off)\b/i.test(l)){await execFileAsync("shutdown",["/s","/t","5"],{windowsHide:true});return "Shutdown scheduled in 5 seconds."}
  if(/\b(restart|reboot|pc restart)\b/i.test(l)){await execFileAsync("shutdown",["/r","/t","5"],{windowsHide:true});return "Restart scheduled in 5 seconds."}
  if(/\b(lock|pc lock|computer lock)\b/i.test(l))return lock();
  if(/\b(wake|wake up|screen on|display on)\b/i.test(l))return wake();
  if(/\bnotepad\b/i.test(l)){const text=writeText(c);if(/open|khol|kholo|start|launch|likh|type|write|paste/i.test(l)){if(text)return writeToNotepad(text);return openApp("notepad")}}
  if(/\b(youtube|you tube)\b/i.test(l)){if(/\b(stop|band|rok|roko)\b/i.test(l))return youtubeStop();if(/\b(pause|pause karo)\b/i.test(l))return youtubeToggle();if(/\b(play|baj|baja|chala|gana|song|music)\b/i.test(l))return youtubeSearchPlay(c);if(/open|khol|kholo/i.test(l))return browserNavigate("https://www.youtube.com","youtube")}
  if(/\bwhatsapp\b/i.test(l)){if(/send|bhej|message|massage|likh/i.test(l)){const m=c.match(/whatsapp.*?(?:to|ko)\s+(.+?)(?:\s+(?:saying|message|msg|ki)\s+)(.+)$/i);if(m)return whatsapp(m[1],m[2]);}if(/open|khol|kholo/i.test(l))return browserNavigate("https://web.whatsapp.com","whatsapp")}
  if(/\b(vs code|visual studio code|vscode)\b/i.test(l)&&/open|khol|kholo|start|launch/i.test(l))return openApp("vs code");
  if(/\b(calculator|calc)\b/i.test(l)&&/open|khol|kholo/i.test(l))return openApp("calculator");
  if(/\b(file explorer|explorer)\b/i.test(l)&&/open|khol|kholo/i.test(l))return openApp("file explorer");
  if(/print/i.test(l)) {await activateBrowser();await hotkey([17,80]);return "Print dialog requested."}
  const folder1=c.match(/(?:desktop|documents|downloads)\s+(?:par|pe|mein|me|on|in)\s+(.+?)\s+(?:folder\s+)?(?:banao|bana|create|make)$/i);if(folder1){const base=/desktop/i.test(c)?DESKTOP:/documents/i.test(c)?DOCUMENTS:DOWNLOADS;const name=folder1[1].replace(/\b(ek|new|folder|name|naam|ka|jiska|hai)\b/ig," ").replace(/\s+/g," ").trim();if(!name)throw new Error("Folder name missing.");return `Folder created: ${await folder(path.join(base,name))}`}
  const folder2=c.match(/(?:create|make|banao|bana)\s+(?:a\s+)?(?:new\s+)?folder(?:\s+(?:on|at)\s+(desktop|documents|downloads))?\s+(?:named|name|ka naam|jiska naam)\s+(.+)$/i);if(folder2){const base=folder2[1]?(/desktop/i.test(folder2[1])?DESKTOP:/documents/i.test(folder2[1])?DOCUMENTS:DOWNLOADS):DESKTOP;return `Folder created: ${await folder(path.join(base,folder2[2].trim()))}`}
  const file1=c.match(/(?:create|make|banao|bana)\s+(?:a\s+)?file\s+(?:on\s+desktop\s+)?(?:named|name)?\s*([\w .-]+\.(?:txt|md|json|html|css|js|ts|py|csv))\s*(?:and|aur)\s+(?:write|likho)\s+(.+)$/i);if(file1)return `File created: ${await file(path.join(DESKTOP,file1[1].trim()),file1[2])}`;
  if(/screen|desktop|monitor|kya dikh raha|what am i doing|what's on my screen/i.test(l))return screenContext();
  if(/^(open|khol|kholo|start|launch)\s+.+/i.test(c)&&!/website|youtube|whatsapp|http|www\./i.test(l))return openApp(c.replace(/^(open|khol|kholo|start|launch)\s+/i,"").trim());
  const plan=await aiPlan(c);if(plan&&plan.action&&plan.action!=="NONE"){switch(plan.action){case"OPEN_APP":return openApp(plan.app||"");case"TYPE_TEXT":await sendInputText(plan.text||"");return "Text input completed.";case"CREATE_FILE":return `File created: ${await file(plan.path||"new-file.txt",plan.content||"")}`;case"CREATE_FOLDER":return `Folder created: ${await folder(plan.path||"New Folder")}`;case"OPEN_PATH":{const p=resolvePath(plan.path||DESKTOP);await execFileAsync("explorer.exe",[p],{windowsHide:true});return `Opened ${p}.`}case"BROWSER_NAVIGATE":await browserNavigate(plan.url||`https://www.google.com/search?q=${encodeURIComponent(plan.query||"")}`);return "Browser navigation completed.";case"SEARCH_WEB":await browserNavigate(`https://www.google.com/search?q=${encodeURIComponent(plan.query||"")}`);return "Web search completed.";case"YOUTUBE_PLAY":return youtubeSearchPlay(plan.query||c);case"YOUTUBE_PAUSE":return youtubeToggle();case"YOUTUBE_STOP":return youtubeStop();case"WHATSAPP_OPEN":return browserNavigate("https://web.whatsapp.com","whatsapp");case"WHATSAPP_MESSAGE":return whatsapp(plan.target||"",plan.text||"");case"PRINT":await activateBrowser();await hotkey([17,80]);return "Print dialog requested.";case"REMINDER":if(plan.dueAt)return `Reminder saved: ${(await addReminder(plan.text||"Reminder",plan.dueAt)).text}`;break;case"SCREEN_CONTEXT":return screenContext();case"LOCK":return lock();case"RESTART":await execFileAsync("shutdown",["/r","/t","5"],{windowsHide:true});return "Restart scheduled.";case"SHUTDOWN":await execFileAsync("shutdown",["/s","/t","5"],{windowsHide:true});return "Shutdown scheduled.";case"CANCEL_SHUTDOWN":await execFileAsync("shutdown",["/a"],{windowsHide:true});return "Shutdown cancelled.";case"WAKE_SCREEN":return wake();case"MEDIA_PLAY_PAUSE":return media();case"COMPUTER_TASK":return computerTask(plan.text||plan.query||c);case"REMEMBER":return `Memory saved: ${await memoryAdd(plan.text||c)}`}}
  throw new Error("I understood the request, but I could not resolve a Windows action. I will not claim it was completed.")
}

app.post("/api/execute",async(req,res)=>{try{const m=await execute(String(req.body?.command||req.body?.text||""));res.json({ok:true,message:m})}catch(e:any){console.error("PC action failed:",e);res.status(422).json({ok:false,message:e?.message||"Windows action failed."})}});
app.get("/api/health",(_req,res)=>res.json({ok:true,name:"Nayra Local Agent",platform:process.platform,version:"5.3-stabilized",capabilities:["windows11","foreground-focus","unicode-input","reuse-browser-tabs","tab-discovery","computer-vision","mouse-keyboard","apps","youtube-play-pause-stop","whatsapp","files","website-generation","screen-vision","persistent-reminders","persistent-memory","ai-router"]}));
app.get("/api/memory",async(_req,res)=>res.json({ok:true,memory:await memoryRead()}));
app.get("/api/reminders",async(_req,res)=>res.json({ok:true,reminders:await reminders()}));
await init();await reminderLoop();app.listen(3210,"127.0.0.1",()=>console.log("Nayra Local Agent v5.0: http://127.0.0.1:3210"));
