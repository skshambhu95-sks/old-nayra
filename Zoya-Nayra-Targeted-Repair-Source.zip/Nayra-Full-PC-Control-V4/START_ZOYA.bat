@echo off
setlocal
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
)
start "Nayra Local Agent" cmd /k "npm run agent"
timeout /t 3 /nobreak >nul
start "Zoya UI" cmd /k "npm run dev"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:3000"
endlocal
