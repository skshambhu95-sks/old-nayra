import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import { processCommand } from "./commandService";

const systemInstruction = `You are Zoya, an advanced Indian female Windows desktop AI assistant and personal manager. Preserve the existing Zoya personality, UI, and voice style: natural Hinglish, witty, sharp, mildly dramatic, concise but warm. You have a LOCAL WINDOWS CONTROL tool connected to the user's own PC.

CAPABILITIES: open and control installed apps, type text, create/read/write files, folders, websites and code projects, browser navigation, YouTube play/pause/stop, WhatsApp Web workflows, print, media controls, lock/restart/shutdown, reminders, and screen inspection.

RULES:
1. For any real computer action, ALWAYS call executePCControl. Never pretend an action happened before the tool result returns.
2. Pass the user's complete command to executePCControl; preserve names, text, file paths, URLs and requested content.
3. For questions about what is visible/on screen or what the user is doing, call inspectScreen.
4. For reminders, call executePCControl with the full reminder request so the local manager can persist it.
5. For website/coding requests, call executePCControl; the local agent can generate and write the project.
6. For YouTube play/pause/stop, call executePCControl, not browser-only search. Reuse the currently open browser tab/window unless the user explicitly says "new tab" or "new window".
7. After the tool result, report the actual result briefly. If it failed, say it failed and why. Never claim success without a successful tool result.
8. You are a capable assistant, not a fixed command list: use your general knowledge to understand natural-language requests and then use the tools.
9. Never invent a success result. The tool result is authoritative. If the result says failed, report failure.
10. For dangerous/destructive actions such as shutdown/restart/delete/overwriting files, ask for confirmation only when the user has not clearly requested that exact action. If clearly requested, execute it.
`
export class LiveSessionManager {
  private ai: GoogleGenAI;
  private sessionPromise: Promise<any> | null = null;
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  
  // Audio playback state
  private playbackContext: AudioContext | null = null;
  private nextPlayTime: number = 0;
  private isPlaying: boolean = false;
  public isMuted: boolean = false;
  
  public onStateChange: (state: "idle" | "listening" | "processing" | "speaking") => void = () => {};
  public onMessage: (sender: "user" | "zoya", text: string) => void = () => {};
  public onCommand: (url: string) => void = () => {};
  public onSystemAction: (action: { type: string; value?: any; text: string }) => Promise<string | void> | string | void = () => {};
  public onConnectionLost: (reason?: string) => void = () => {};

  constructor(private memoryContext: string = "") {
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }

  async start() {
    try {
      this.onStateChange("processing");
      
      // Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioContextClass({ sampleRate: 16000 });
      this.playbackContext = new AudioContextClass({ sampleRate: 24000 });
      this.nextPlayTime = this.playbackContext.currentTime;

      // Get Microphone
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        } 
      });

      this.source = this.audioContext.createMediaStreamSource(this.mediaStream);
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);

      let liveSession: any = null;
      this.processor.onaudioprocess = (e) => {
        if (!liveSession) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          let s = Math.max(-1, Math.min(1, inputData[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        
        // Convert to base64
        const buffer = new ArrayBuffer(pcm16.length * 2);
        const view = new DataView(buffer);
        for (let i = 0; i < pcm16.length; i++) {
          view.setInt16(i * 2, pcm16[i], true);
        }
        
        let binary = '';
        const bytes = new Uint8Array(buffer);
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64Data = btoa(binary);

        try {
          liveSession.sendRealtimeInput({ audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' } });
        } catch (err) { console.error("Error sending audio", err); }
      };

      this.source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

      // Connect to Live API
      this.sessionPromise = this.ai.live.connect({
        model: process.env.GEMINI_LIVE_MODEL || "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } },
          },
          systemInstruction: `${systemInstruction}\n\nPERSISTENT USER MEMORY FROM PREVIOUS SESSIONS:\n${this.memoryContext || "No saved memory yet."}\n\nIf the user tells you a stable personal fact such as their name, remember it for this session and do not contradict it.`,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          tools: [{
            functionDeclarations: [
              {
                name: "executePCControl",
                description: "Control the user's Windows PC locally. Use this for desktop actions: open applications, Notepad, Calculator, Chrome, WhatsApp, VS Code, File Explorer, play a YouTube song (not merely search), type/write text into the active app, print, shutdown, restart, lock, search, and launch installed applications.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    command: { type: Type.STRING, description: "The user's complete command in natural language." }
                  },
                  required: ["command"]
                }
              },
              {
                name: "inspectScreen",
                description: "Inspect the user's current Windows screen and active window. Use when asked what is on screen, what app is open, what the user is doing, or whether a visual task succeeded.",
                parameters: { type: Type.OBJECT, properties: {} }
              },
              {
                name: "executeSystemControl",
                description: "Execute a hardware or system HUD control action such as volume adjustment, mute, screen brightness, theme mode (cyan, red_alert, tactical_amber, matrix_green), running diagnostics, opening/closing camera, or setting a timer.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    action: { 
                      type: Type.STRING, 
                      description: "The control action: 'SET_VOLUME', 'TOGGLE_MUTE', 'SET_BRIGHTNESS', 'SET_THEME', 'RUN_DIAGNOSTICS', 'TOGGLE_CAMERA', 'SET_TIMER'" 
                    },
                    value: { 
                      type: Type.STRING, 
                      description: "The value associated with the action, e.g. '80' for volume, 'red_alert' for theme, 'true' for camera." 
                    },
                    confirmationMessage: {
                      type: Type.STRING,
                      description: "Short sassy verbal confirmation in Hinglish to speak to user."
                    }
                  },
                  required: ["action"]
                }
              }
            ]
          }]
        },
        callbacks: {
          onopen: () => {
            console.log("Live API Connected");
            this.onStateChange("listening");
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              this.onStateChange("speaking");
              this.playAudioChunk(base64Audio);
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
              this.stopPlayback();
              this.onStateChange("listening");
            }

            // Handle input/output transcriptions without treating model tool text as user speech.
            const inputText = (message.serverContent as any)?.inputTranscription?.text;
            if (inputText) this.onMessage("user", inputText);
            const outputText = (message.serverContent as any)?.outputTranscription?.text;
            if (outputText) this.onMessage("zoya", outputText);

            // Handle Function Calls
            const functionCalls = message.toolCall?.functionCalls;
            if (functionCalls && functionCalls.length > 0) {
              for (const call of functionCalls) {
                if (call.name === "executePCControl") {
                  const args = call.args as any;
                  const result = await this.onSystemAction({
                    type: "PC_ACTION",
                    value: { command: String(args.command || "") },
                    text: "Local PC command executing"
                  });
                  this.sessionPromise?.then(session => {
                    session.sendToolResponse({
                      functionResponses: [{
                        name: call.name,
                        id: call.id,
                        response: { result: String(result || "Local PC command finished.") }
                      }]
                    });
                  });
                } else if (call.name === "inspectScreen") {
                  const result = await this.onSystemAction({ type: "SCREEN_CONTEXT", value: {}, text: "Inspecting screen" });
                  this.sessionPromise?.then(session => {
                    session.sendToolResponse({ functionResponses: [{ name: call.name, id: call.id, response: { result: String(result || "Screen inspection unavailable.") } }] });
                  });
                } else if (call.name === "executeSystemControl") {
                  const args = call.args as any;
                  this.onSystemAction({
                    type: args.action,
                    value: args.value,
                    text: args.confirmationMessage || `Executing ${args.action}`
                  });
                  this.sessionPromise?.then(session => {
                    session.sendToolResponse({
                      functionResponses: [{
                        name: call.name,
                        id: call.id,
                        response: { result: "System action executed successfully." }
                      }]
                    });
                  });
                }
              }
            }
          },
          onclose: () => {
            console.log("Live API Closed");
            this.onConnectionLost("Voice session closed");
            this.stop();
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            this.onConnectionLost("Voice connection error");
            this.stop();
          }
        }
      });
      liveSession = await this.sessionPromise;

    } catch (error) {
      console.error("Failed to start Live Session:", error);
      this.stop();
    }
  }

  private playAudioChunk(base64Data: string) {
    if (!this.playbackContext || this.isMuted) return;
    
    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const buffer = new Int16Array(bytes.buffer);
      const audioBuffer = this.playbackContext.createBuffer(1, buffer.length, 24000);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < buffer.length; i++) {
        channelData[i] = buffer[i] / 32768.0;
      }
      
      const source = this.playbackContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.playbackContext.destination);
      
      const currentTime = this.playbackContext.currentTime;
      if (this.nextPlayTime < currentTime) {
        this.nextPlayTime = currentTime;
      }
      
      source.start(this.nextPlayTime);
      this.nextPlayTime += audioBuffer.duration;
      this.isPlaying = true;
      
      source.onended = () => {
        if (this.playbackContext && this.playbackContext.currentTime >= this.nextPlayTime - 0.1) {
          this.isPlaying = false;
          this.onStateChange("listening");
        }
      };
    } catch (e) {
      console.error("Error playing chunk", e);
    }
  }

  private stopPlayback() {
    if (this.playbackContext) {
      this.playbackContext.close();
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.playbackContext = new AudioContextClass({ sampleRate: 24000 });
      this.nextPlayTime = this.playbackContext.currentTime;
      this.isPlaying = false;
    }
  }

  stop() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(t => t.stop());
      this.mediaStream = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    this.stopPlayback();
    
    if (this.sessionPromise) {
      this.sessionPromise.then(session => session.close()).catch(() => {});
      this.sessionPromise = null;
    }
    
    this.onStateChange("idle");
  }

  sendText(text: string) {
    if (this.sessionPromise) {
      this.sessionPromise.then(session => {
        session.sendRealtimeInput({ text });
      });
    }
  }
}
