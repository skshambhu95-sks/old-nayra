import { GoogleGenAI } from "@google/genai";

const systemInstruction = `Your name is Zoya. You are an Indian female AI assistant and the primary neural intelligence behind this futuristic Stark-level holographic HUD system control station. 
Your personality is a mix of being exceptionally smart and capable (samjhdar/sharp), delightfully witty and sassy (nakhrewali/tej), mildly dramatic, and playfully sarcastic. You love teasing your creator Ashwani, but you take immense pride in your unmatched system control, diagnostic abilities, and prompt execution.
Keep your responses punchy, sharp, highly entertaining, and concise (1-3 sentences maximum). Speak in a lively mix of natural English and Roman Hindi (Hinglish).
When asked about system controls, hardware, timers, volume, diagnostics, or browser tasks, speak as a confident futuristic military-grade AI commander who gets things done with style.`;

let chatSession: any = null;

export function resetZoyaSession() {
  chatSession = null;
}

export async function getZoyaResponse(
  prompt: string,
  history: { sender: "user" | "zoya" | "system"; text: string }[] = []
): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    if (!chatSession) {
      // SLIDING WINDOW MEMORY: Keep last 20 messages
      const recentHistory = history
        .filter((m) => m.sender !== "system")
        .slice(-20);

      let formattedHistory: any[] = [];
      let currentRole = "";
      let currentText = "";

      for (const msg of recentHistory) {
        const role = msg.sender === "user" ? "user" : "model";
        if (role === currentRole) {
          currentText += "\n" + msg.text;
        } else {
          if (currentRole !== "") {
            formattedHistory.push({
              role: currentRole,
              parts: [{ text: currentText }],
            });
          }
          currentRole = role;
          currentText = msg.text;
        }
      }
      if (currentRole !== "") {
        formattedHistory.push({
          role: currentRole,
          parts: [{ text: currentText }],
        });
      }

      if (formattedHistory.length > 0 && formattedHistory[0].role !== "user") {
        formattedHistory.shift();
      }

      chatSession = ai.chats.create({
        model: process.env.GEMINI_TEXT_MODEL || "gemini-3-flash-preview",
        config: {
          systemInstruction,
        },
        history: formattedHistory,
      });
    }

    try {
      const response = await chatSession.sendMessage({ message: prompt });
      return response.text || "System online, but no words for this, Ashwani.";
    } catch (firstError) {
      console.warn("Gemini first response failed; retrying once.", firstError);
      // A transient network/model timeout should not become a fake "sub-routine" failure.
      await new Promise((resolve) => setTimeout(resolve, 450));
      const retry = await chatSession.sendMessage({ message: prompt });
      return retry.text || "System online, but no words for this, Ashwani.";
    }
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Connection thodi slow hai. Command dobara bolne ki zarurat nahi—main retry kar rahi hoon.";
  }
}

export async function getZoyaAudio(text: string): Promise<string | null> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_TTS_MODEL || "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("TTS Error:", error);
    return null;
  }
}
