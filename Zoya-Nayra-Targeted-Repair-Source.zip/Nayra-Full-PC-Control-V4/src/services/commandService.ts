import { HudTheme } from "../types";

export interface SystemActionPayload {
  type:
    | "SET_VOLUME"
    | "SET_BRIGHTNESS"
    | "SET_THEME"
    | "TOGGLE_MUTE"
    | "RUN_DIAGNOSTICS"
    | "SET_TIMER"
    | "TOGGLE_CAMERA"
    | "ADD_NOTE"
    | "CLEAR_NOTES"
    | "CLEAR_HISTORY"
    | "TOGGLE_FULLSCREEN"
    | "BROWSER_ACTION"
    | "PC_ACTION"
    | "NONE";
  value?: any;
  url?: string;
  actionText: string;
}

export function processCommand(command: string): SystemActionPayload {
  const lowerCmd = command.toLowerCase().trim();

  // 1. SYSTEM AUDIO / VOLUME CONTROL
  const volumeSetMatch = lowerCmd.match(/(?:set\s+)?volume\s+(?:to\s+)?(\d+)\s*%?/);
  if (volumeSetMatch) {
    const vol = Math.min(100, Math.max(0, parseInt(volumeSetMatch[1], 10)));
    return {
      type: "SET_VOLUME",
      value: vol,
      actionText: `System volume ${vol}% pe set kar diya hai. Ab clear sunayi de raha hai na?`
    };
  }

  if (lowerCmd.includes("volume up") || lowerCmd.includes("increase volume") || lowerCmd.includes("awaz badhao")) {
    return {
      type: "SET_VOLUME",
      value: "+15",
      actionText: "Volume boost applied (+15%). Bass check, mic check!"
    };
  }

  if (lowerCmd.includes("volume down") || lowerCmd.includes("decrease volume") || lowerCmd.includes("awaz kam karo")) {
    return {
      type: "SET_VOLUME",
      value: "-15",
      actionText: "Volume decreased (-15%). Shanti chahiye toh pehle bolte!"
    };
  }

  if (lowerCmd === "mute" || lowerCmd.includes("mute audio") || lowerCmd.includes("chup raho") || lowerCmd.includes("mute system")) {
    return {
      type: "TOGGLE_MUTE",
      value: true,
      actionText: "Audio muted. Lo, bilkul khamoshi."
    };
  }

  if (lowerCmd === "unmute" || lowerCmd.includes("unmute audio") || lowerCmd.includes("bolna shuru karo")) {
    return {
      type: "TOGGLE_MUTE",
      value: false,
      actionText: "Audio unmuted! Back online and louder than ever."
    };
  }

  // 2. HUD DISPLAY / BRIGHTNESS & THEME CONTROL
  const brightMatch = lowerCmd.match(/(?:set\s+)?brightness\s+(?:to\s+)?(\d+)\s*%?/);
  if (brightMatch) {
    const br = Math.min(100, Math.max(15, parseInt(brightMatch[1], 10)));
    return {
      type: "SET_BRIGHTNESS",
      value: br,
      actionText: `HUD display illumination calibrated to ${br}%. Perfect for your eyes.`
    };
  }

  if (lowerCmd.includes("red alert") || lowerCmd.includes("emergency mode") || lowerCmd.includes("danger mode")) {
    return {
      type: "SET_THEME",
      value: "red_alert" as HudTheme,
      actionText: "RED ALERT PROTOCOL ENGAGED! Threat defense subsystems online. All shields up!"
    };
  }

  if (lowerCmd.includes("tactical mode") || lowerCmd.includes("amber mode") || lowerCmd.includes("stealth mode")) {
    return {
      type: "SET_THEME",
      value: "tactical_amber" as HudTheme,
      actionText: "Tactical Amber HUD activated. High-contrast battlefield optics engaged."
    };
  }

  if (lowerCmd.includes("matrix mode") || lowerCmd.includes("green mode") || lowerCmd.includes("cyber green")) {
    return {
      type: "SET_THEME",
      value: "matrix_green" as HudTheme,
      actionText: "Matrix Emerald terminal engaged. Entering deep mainframe cyberspace."
    };
  }

  if (lowerCmd.includes("cyan mode") || lowerCmd.includes("normal mode") || lowerCmd.includes("default theme") || lowerCmd.includes("prime mode")) {
    return {
      type: "SET_THEME",
      value: "cyan" as HudTheme,
      actionText: "Core Cyan Prime theme restored. Arc reactor balance is 100% nominal."
    };
  }

  // 3. SYSTEM DIAGNOSTICS & TELEMETRY
  if (
    lowerCmd.includes("run diagnostic") ||
    lowerCmd.includes("system check") ||
    lowerCmd.includes("diagnostics") ||
    lowerCmd.includes("system status") ||
    lowerCmd.includes("scan system")
  ) {
    return {
      type: "RUN_DIAGNOSTICS",
      actionText: "Initiating full system diagnostic sweep! Core telemetry nominal, memory buffers synchronized, network connection optimal. Zoya is operating at peak intelligence!"
    };
  }

  // 4. OPTICAL SENSOR / CAMERA HUD
  if (lowerCmd.includes("open camera") || lowerCmd.includes("activate camera") || lowerCmd.includes("scan face") || lowerCmd.includes("optical sensor")) {
    return {
      type: "TOGGLE_CAMERA",
      value: true,
      actionText: "Optical HUD sensor activated. Target acquisition grid online. You're looking sharp, Ashwani!"
    };
  }

  if (lowerCmd.includes("close camera") || lowerCmd.includes("turn off camera") || lowerCmd.includes("deactivate camera")) {
    return {
      type: "TOGGLE_CAMERA",
      value: false,
      actionText: "Optical HUD sensors shuttered and secured."
    };
  }

  // 5. TIMER / CHRONOMETER
  const timerMatch = lowerCmd.match(/(?:set\s+(?:a\s+)?)?timer\s+(?:for\s+)?(\d+)\s*(minute|minutes|second|seconds|min|sec)/);
  if (timerMatch) {
    const num = parseInt(timerMatch[1], 10);
    const unit = timerMatch[2].toLowerCase();
    const seconds = unit.startsWith("s") ? num : num * 60;
    const label = `${num} ${unit}`;
    return {
      type: "SET_TIMER",
      value: { seconds, label },
      actionText: `Timer set for ${label}! Countdown locked in. Focus karo, main nazar rakh rahi hoon.`
    };
  }

  // 6. SCRATCHPAD / NOTES
  const noteMatch = lowerCmd.match(/(?:take\s+(?:a\s+)?note|note\s+down|save\s+note)\s*[:]?\s*(.+)/);
  if (noteMatch) {
    return {
      type: "ADD_NOTE",
      value: noteMatch[1].trim(),
      actionText: `Note secure memory bank me save kar liya hai: "${noteMatch[1].trim()}"`
    };
  }

  if (lowerCmd.includes("clear note") || lowerCmd.includes("delete notes")) {
    return {
      type: "CLEAR_NOTES",
      actionText: "Scratchpad memory wiped clean."
    };
  }

  // 7. TIME & DATE READOUTS
  if (lowerCmd.includes("what time is it") || lowerCmd.includes("current time") || lowerCmd.includes("time kya hai") || lowerCmd === "time") {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    return {
      type: "NONE",
      actionText: `Current system time is ${timeStr}. Time is running, aur aapka kaam baaki hai!`
    };
  }

  if (lowerCmd.includes("what is today's date") || lowerCmd.includes("aaj ki date") || lowerCmd.includes("today date")) {
    const now = new Date();
    const dateStr = now.toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    return {
      type: "NONE",
      actionText: `Today's date is ${dateStr}. Make it productive!`
    };
  }

  // 8. FULLSCREEN
  if (lowerCmd.includes("fullscreen") || lowerCmd.includes("full screen")) {
    return {
      type: "TOGGLE_FULLSCREEN",
      actionText: "Toggling immersive holographic fullscreen display!"
    };
  }

  // 9. CLEAR HISTORY
  if (lowerCmd.includes("clear chat") || lowerCmd.includes("clear history") || lowerCmd.includes("wipe terminal")) {
    return {
      type: "CLEAR_HISTORY",
      actionText: "Chat buffers flushed and memory caches refreshed."
    };
  }

  // 10. LOCAL WINDOWS / PC AGENT — route first so browser-only handlers cannot
  // swallow commands such as "YouTube par gana bajao" or "Notepad kholo".
  const pcHints = [
    "notepad", "calculator", "calc", "chrome", "browser", "whatsapp", "vs code",
    "visual studio", "explorer", "file explorer", "shutdown", "shut down", "restart",
    "reboot", "sleep", "lock", "print", "type ", "likho", "write ", "khol", "open app",
    "youtube par", "youtube pe", "youtube me", "youtube mein", "play song", "gana bajao",
    "gana chalao", "song bajao", "song chalao", "search karo", "app kholo", "application kholo"
  ];
  if (pcHints.some((hint) => lowerCmd.includes(hint))) {
    return {
      type: "PC_ACTION",
      value: { command: command.trim() },
      actionText: "Haan, local PC control activate hai. Command execute kar rahi hoon."
    };
  }

  // 10. EXTERNAL BROWSER ACTIONS & LAUNCHERS
  // YouTube search / Play
  const ytMatch = lowerCmd.match(/^play\s+(.+?)\s+on\s+youtube$/) || lowerCmd.match(/play\s+(.+?)\s+youtube/);
  if (ytMatch) {
    const query = encodeURIComponent(ytMatch[1].trim());
    return {
      type: "BROWSER_ACTION",
      url: `https://www.youtube.com/results?search_query=${query}`,
      actionText: `Playing "${ytMatch[1]}" on YouTube. Popcorn ready rakha hai?`
    };
  }

  if (lowerCmd === "open youtube" || lowerCmd.includes("youtube kholo")) {
    return {
      type: "BROWSER_ACTION",
      url: "https://www.youtube.com",
      actionText: "Opening YouTube command station. Entertainment mode online."
    };
  }

  // Spotify
  const spotifyMatch = lowerCmd.match(/^search\s+(.+?)\s+on\s+spotify$/) || lowerCmd.match(/play\s+(.+?)\s+on\s+spotify/);
  if (spotifyMatch) {
    const query = encodeURIComponent(spotifyMatch[1].trim());
    return {
      type: "BROWSER_ACTION",
      url: `https://open.spotify.com/search/${query}`,
      actionText: `Searching "${spotifyMatch[1]}" on Spotify. Achha gaana choose karna!`
    };
  }

  if (lowerCmd === "open spotify") {
    return {
      type: "BROWSER_ACTION",
      url: "https://open.spotify.com",
      actionText: "Opening Spotify sound deck."
    };
  }

  // WhatsApp
  const waMatch = lowerCmd.match(
    /^send\s+(?:a\s+)?whatsapp\s+(?:message\s+)?to\s+([\d\+\s]+)\s+saying\s+(.+)$/
  );
  if (waMatch) {
    const number = waMatch[1].replace(/\s+/g, "");
    const message = encodeURIComponent(waMatch[2].trim());
    return {
      type: "BROWSER_ACTION",
      url: `https://web.whatsapp.com/send?phone=${number}&text=${message}`,
      actionText: `Dispatching WhatsApp dispatch to ${number}. Let's hope they reply promptly, Ashwani!`
    };
  }

  // Google Search
  const googleSearchMatch = lowerCmd.match(/(?:search|google)\s+(?:for\s+)?(.+)/);
  if (googleSearchMatch && !lowerCmd.includes("spotify") && !lowerCmd.includes("youtube")) {
    const query = encodeURIComponent(googleSearchMatch[1].trim());
    return {
      type: "BROWSER_ACTION",
      url: `https://www.google.com/search?q=${query}`,
      actionText: `Searching Google database for "${googleSearchMatch[1]}". Scanning global intel.`
    };
  }

  // Maps
  const mapsMatch = lowerCmd.match(/(?:open\s+)?maps?\s+(?:to|for)\s+(.+)/);
  if (mapsMatch) {
    const query = encodeURIComponent(mapsMatch[1].trim());
    return {
      type: "BROWSER_ACTION",
      url: `https://www.google.com/maps/search/${query}`,
      actionText: `Calculating navigation vector to ${mapsMatch[1]} on Google Maps.`
    };
  }

  // Weather
  const weatherMatch = lowerCmd.match(/weather\s+(?:in|for|at)?\s*(.+)/);
  if (weatherMatch) {
    const query = encodeURIComponent(weatherMatch[1].trim() + " weather");
    return {
      type: "BROWSER_ACTION",
      url: `https://www.google.com/search?q=${query}`,
      actionText: `Checking atmospheric weather telemetry for ${weatherMatch[1]}.`
    };
  }

  // General "Open [site]"
  const openMatch = lowerCmd.match(/^open\s+([a-z0-9\.\-]+)$/);
  if (openMatch) {
    let site = openMatch[1].trim().replace(/\s+/g, "");
    if (!site.includes(".")) {
      if (site === "github") site = "github.com";
      else if (site === "twitter" || site === "x") site = "x.com";
      else if (site === "reddit") site = "reddit.com";
      else if (site === "wikipedia") site = "wikipedia.org";
      else site += ".com";
    }
    return {
      type: "BROWSER_ACTION",
      url: `https://www.${site}`,
      actionText: `Opening ${site}. Command executed.`
    };
  }

  return {
    type: "NONE",
    actionText: ""
  };
}
