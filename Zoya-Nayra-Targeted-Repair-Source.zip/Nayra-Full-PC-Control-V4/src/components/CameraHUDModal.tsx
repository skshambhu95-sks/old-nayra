import React, { useEffect, useRef, useState, useMemo } from "react";
import { X, Camera, Scan, Shield } from "lucide-react";
import { HudTheme } from "../types";
import { getThemeConfig } from "../utils/themeStyles";
import { sfx } from "../utils/sfx";

interface CameraHUDModalProps {
  theme: HudTheme;
  onClose: () => void;
}

export default function CameraHUDModal({ theme, onClose }: CameraHUDModalProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [targetLocked, setTargetLocked] = useState(false);

  useEffect(() => {
    let activeStream: MediaStream | null = null;
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "user" },
        })
        .then((s) => {
          activeStream = s;
          setStream(s);
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
        })
        .catch((err) => {
          console.warn("Camera access not available or denied:", err);
          setCameraError("Camera feed offline. Engaging synthetic tactical sensor preview.");
        });
    } else {
      setCameraError("Media devices unsupported. Synthetic optic simulation engaged.");
    }

    const lockTimer = setTimeout(() => {
      setTargetLocked(true);
      sfx.playConfirm();
    }, 1200);

    return () => {
      clearTimeout(lockTimer);
      if (activeStream) {
        activeStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4">
      <div
        className="relative w-full max-w-lg rounded-2xl border p-5 flex flex-col gap-3 shadow-2xl backdrop-blur-xl overflow-hidden"
        style={{
          backgroundColor: "rgba(2, 7, 13, 0.95)",
          borderColor: `${cfg.primary}60`,
          boxShadow: `0 0 40px ${cfg.primary}30`,
        }}
      >
        {/* Top HUD Header */}
        <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${cfg.primary}30` }}>
          <div className="flex items-center gap-2">
            <Scan size={16} style={{ color: cfg.primary }} className="animate-spin" />
            <span className="font-mono text-sm tracking-widest font-bold uppercase" style={{ color: cfg.primary }}>
              OPTICAL SENSOR // FACIAL ACQUISITION
            </span>
          </div>
          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="p-1 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Video Stage with Holographic HUD Overlays */}
        <div className="relative w-full aspect-4/3 bg-black rounded-xl overflow-hidden border border-white/10 flex items-center justify-center">
          {cameraError ? (
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <Camera size={40} style={{ color: cfg.primary }} className="mb-2 opacity-50" />
              <p className="font-mono text-xs text-white/70">{cameraError}</p>
              <div className="mt-4 px-3 py-1 bg-white/5 border border-white/10 rounded font-mono text-[10px] text-white/50">
                [SYNTHETIC FACIAL TELEMETRY LOCK: ACTIVE]
              </div>
            </div>
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover transform -scale-x-100 opacity-80"
            />
          )}

          {/* Sci-Fi Targeting Reticle & Face Lock Box */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            {/* Corner Brackets */}
            <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2" style={{ borderColor: cfg.primary }} />
            <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2" style={{ borderColor: cfg.primary }} />
            <div className="absolute bottom-4 left-4 w-6 h-7 border-b-2 border-l-2" style={{ borderColor: cfg.primary }} />
            <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2" style={{ borderColor: cfg.primary }} />

            {/* Central Targeting Box */}
            <div
              className={`w-44 h-52 border rounded-lg transition-all duration-500 flex flex-col justify-between p-2 ${
                targetLocked ? "scale-100" : "scale-110"
              }`}
              style={{
                borderColor: targetLocked ? cfg.primary : `${cfg.primary}40`,
                boxShadow: targetLocked ? `0 0 15px ${cfg.primary}50` : "none",
              }}
            >
              <div className="flex justify-between font-mono text-[9px]" style={{ color: cfg.primary }}>
                <span>ID: CREATOR</span>
                <span>{targetLocked ? "TARGET LOCKED" : "SEARCHING..."}</span>
              </div>
              <div className="flex justify-between font-mono text-[9px]" style={{ color: cfg.primary }}>
                <span>DIST: 0.65m</span>
                <span>MATCH: 99.8%</span>
              </div>
            </div>

            {/* Sweep Scanline */}
            <div
              className="absolute left-0 right-0 h-0.5 pointer-events-none animate-pulse"
              style={{
                backgroundColor: cfg.primary,
                boxShadow: `0 0 8px ${cfg.primary}`,
                top: "45%",
              }}
            />
          </div>
        </div>

        {/* Bottom Sensor Telemetry */}
        <div className="flex items-center justify-between font-mono text-xs text-white/70 pt-1">
          <span className="flex items-center gap-1.5">
            <Shield size={12} style={{ color: cfg.primary }} /> BIOMETRIC RECOGNITION: VERIFIED
          </span>
          <button
            onClick={() => {
              sfx.playConfirm();
              onClose();
            }}
            className="px-4 py-1.5 rounded-lg border font-mono text-xs font-semibold hover:bg-white/10 transition-colors"
            style={{
              borderColor: `${cfg.primary}50`,
              color: cfg.primary,
            }}
          >
            DISMISS SENSOR
          </button>
        </div>
      </div>
    </div>
  );
}
