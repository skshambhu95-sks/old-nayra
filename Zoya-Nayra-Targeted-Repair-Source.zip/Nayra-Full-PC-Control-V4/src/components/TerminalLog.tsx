import React, { useMemo } from "react";
import { Terminal, X, Trash2, CheckCircle2 } from "lucide-react";
import { HudTheme } from "../types";
import { getThemeConfig } from "../utils/themeStyles";
import { sfx } from "../utils/sfx";

export interface LogEntry {
  id: string;
  time: string;
  type: "CMD" | "AUDIO" | "SYS" | "AI" | "WARN";
  message: string;
}

interface TerminalLogProps {
  theme: HudTheme;
  logs: LogEntry[];
  onClear: () => void;
  onClose: () => void;
}

export default function TerminalLog({ theme, logs, onClear, onClose }: TerminalLogProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);

  return (
    <div className="fixed inset-x-4 bottom-28 md:inset-x-auto md:right-8 md:bottom-28 md:w-[480px] z-40 bg-black/90 backdrop-blur-xl border rounded-xl p-4 shadow-2xl flex flex-col gap-2 max-h-[360px] overflow-hidden"
      style={{
        borderColor: `${cfg.primary}50`,
        boxShadow: `0 0 30px ${cfg.primary}25`,
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${cfg.primary}30` }}>
        <div className="flex items-center gap-2 font-mono text-xs font-bold tracking-wider uppercase" style={{ color: cfg.primary }}>
          <Terminal size={14} />
          <span>ZOYA SYSTEM TERMINAL // REPL</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              sfx.playClick();
              onClear();
            }}
            className="p-1 text-white/50 hover:text-white/90 hover:bg-white/10 rounded transition-colors"
            title="Clear Log"
          >
            <Trash2 size={13} />
          </button>
          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="p-1 text-white/50 hover:text-white/90 hover:bg-white/10 rounded transition-colors"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Logs Scroll Container */}
      <div className="flex-1 overflow-y-auto font-mono text-[11px] flex flex-col gap-1 pr-1 hud-scrollbar">
        {logs.length === 0 ? (
          <div className="text-white/40 italic text-center py-6">Terminal buffer empty. Systems nominal.</div>
        ) : (
          logs.map((log) => {
            const color =
              log.type === "CMD"
                ? cfg.primary
                : log.type === "AI"
                ? "#c084fc"
                : log.type === "WARN"
                ? "#ef4444"
                : "#60a5fa";

            return (
              <div key={log.id} className="flex items-start gap-2 leading-tight py-0.5 border-b border-white/5">
                <span className="text-white/40 shrink-0 text-[10px]">{log.time}</span>
                <span
                  className="font-bold text-[9px] px-1 rounded uppercase shrink-0"
                  style={{
                    backgroundColor: `${color}20`,
                    color: color,
                    border: `1px solid ${color}40`,
                  }}
                >
                  {log.type}
                </span>
                <span className="text-white/90 break-words flex-1">{log.message}</span>
              </div>
            );
          })
        )}
      </div>

      {/* Status footer */}
      <div className="flex items-center justify-between text-[10px] font-mono text-white/50 pt-1 border-t border-white/10">
        <span className="flex items-center gap-1">
          <CheckCircle2 size={10} className="text-emerald-400" /> DAEMON ACTIVE
        </span>
        <span>{logs.length} EVENTS RECORDED</span>
      </div>
    </div>
  );
}
