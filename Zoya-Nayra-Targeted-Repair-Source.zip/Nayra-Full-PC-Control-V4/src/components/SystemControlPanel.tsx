import React, { useMemo } from "react";
import { 
  Volume2, 
  VolumeX, 
  Sun, 
  Palette, 
  Camera, 
  Terminal, 
  FileText, 
  Sliders, 
  Play, 
  ShieldAlert, 
  Timer,
  ExternalLink
} from "lucide-react";
import { HudTheme, SystemControlState } from "../types";
import { getThemeConfig } from "../utils/themeStyles";
import { sfx } from "../utils/sfx";

interface SystemControlPanelProps {
  systemState: SystemControlState;
  onUpdateState: (updater: (prev: SystemControlState) => SystemControlState) => void;
  onTriggerCommand: (cmd: string) => void;
  onOpenNotes: () => void;
}

export default function SystemControlPanel({
  systemState,
  onUpdateState,
  onTriggerCommand,
  onOpenNotes,
}: SystemControlPanelProps) {
  const cfg = useMemo(() => getThemeConfig(systemState.theme), [systemState.theme]);

  const themes: { id: HudTheme; label: string; color: string }[] = [
    { id: "cyan", label: "CYAN", color: "#00f0ff" },
    { id: "red_alert", label: "ALERT", color: "#ef4444" },
    { id: "tactical_amber", label: "AMBER", color: "#f59e0b" },
    { id: "matrix_green", label: "MATRIX", color: "#22c55e" },
  ];

  return (
    <div
      className="flex flex-col gap-3.5 p-4 rounded-xl border backdrop-blur-md transition-all duration-300 w-full max-w-[300px] select-none"
      style={{
        backgroundColor: "rgba(2, 7, 13, 0.75)",
        borderColor: `${cfg.primary}35`,
        boxShadow: `0 0 20px ${cfg.primary}15`,
      }}
    >
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${cfg.primary}30` }}>
        <div className="flex items-center gap-2">
          <Sliders size={14} style={{ color: cfg.primary }} />
          <span className="font-mono text-xs tracking-wider uppercase font-bold" style={{ color: cfg.primary }}>
            SYSTEM CONTROL // MATRIX
          </span>
        </div>
        <span className="font-mono text-[10px] tracking-widest text-white/50">DIRECT-IO</span>
      </div>

      {/* 1. MASTER AUDIO GAIN (VOLUME) */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-white/70 flex items-center gap-1.5">
            {systemState.isMuted ? (
              <VolumeX size={13} className="text-red-400" />
            ) : (
              <Volume2 size={13} style={{ color: cfg.primary }} />
            )}
            AUDIO GAIN
          </span>
          <div className="flex items-center gap-2">
            <span className="font-bold" style={{ color: cfg.primary }}>
              {systemState.isMuted ? "MUTED" : `${systemState.volume}%`}
            </span>
            <button
              onClick={() => {
                sfx.playClick();
                onUpdateState((s) => ({ ...s, isMuted: !s.isMuted }));
              }}
              className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-white/10 hover:border-white/30 text-white/70 transition-colors"
            >
              {systemState.isMuted ? "UNMUTE" : "MUTE"}
            </button>
          </div>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={systemState.volume}
          onChange={(e) => {
            const val = parseInt(e.target.value, 10);
            onUpdateState((s) => ({ ...s, volume: val, isMuted: false }));
          }}
          className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-white/10 rounded-lg appearance-none"
          style={{ accentColor: cfg.primary }}
        />
      </div>

      {/* 2. ILLUMINATION (BRIGHTNESS) */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-white/70 flex items-center gap-1.5">
            <Sun size={13} style={{ color: cfg.primary }} /> HUD BRIGHTNESS
          </span>
          <span className="font-bold" style={{ color: cfg.primary }}>
            {systemState.brightness}%
          </span>
        </div>
        <input
          type="range"
          min="25"
          max="100"
          value={systemState.brightness}
          onChange={(e) => {
            const val = parseInt(e.target.value, 10);
            onUpdateState((s) => ({ ...s, brightness: val }));
          }}
          className="w-full cursor-pointer h-1.5 bg-white/10 rounded-lg appearance-none"
          style={{ accentColor: cfg.primary }}
        />
      </div>

      {/* 3. HUD THEME SELECTOR */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-white/70 flex items-center gap-1.5">
            <Palette size={13} style={{ color: cfg.primary }} /> HOLO THEME
          </span>
          <span className="font-mono text-[10px]" style={{ color: cfg.primary }}>
            {cfg.name}
          </span>
        </div>
        <div className="grid grid-cols-4 gap-1">
          {themes.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                sfx.playClick();
                if (t.id === "red_alert") sfx.playAlert();
                onUpdateState((s) => ({ ...s, theme: t.id }));
              }}
              className={`py-1 text-[10px] font-mono rounded border transition-all ${
                systemState.theme === t.id
                  ? "font-bold text-white shadow-sm"
                  : "text-white/60 hover:text-white border-white/10 hover:border-white/20 bg-white/5"
              }`}
              style={{
                borderColor: systemState.theme === t.id ? t.color : undefined,
                backgroundColor: systemState.theme === t.id ? `${t.color}25` : undefined,
                color: systemState.theme === t.id ? t.color : undefined,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* 4. SENSORS & SYSTEM UTILITIES */}
      <div className="flex flex-col gap-1.5 pt-1">
        <span className="font-mono text-[10px] text-white/50 tracking-wider uppercase">
          TACTICAL MODULES
        </span>
        <div className="grid grid-cols-2 gap-1.5 font-mono text-xs">
          {/* Optical Sensor / Camera Button */}
          <button
            onClick={() => {
              sfx.playClick();
              onUpdateState((s) => ({ ...s, cameraActive: !s.cameraActive }));
            }}
            className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded border transition-all ${
              systemState.cameraActive
                ? "bg-red-500/20 text-red-300 border-red-500/50 animate-pulse"
                : "bg-white/5 text-white/80 border-white/10 hover:border-white/30"
            }`}
          >
            <Camera size={13} style={{ color: systemState.cameraActive ? "#ef4444" : cfg.primary }} />
            <span className="text-[11px] font-medium">
              {systemState.cameraActive ? "OPTIC ACTIVE" : "OPTIC HUD"}
            </span>
          </button>

          {/* Terminal Console Log Toggle */}
          <button
            onClick={() => {
              sfx.playClick();
              onUpdateState((s) => ({ ...s, terminalOpen: !s.terminalOpen }));
            }}
            className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded border transition-all ${
              systemState.terminalOpen
                ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50"
                : "bg-white/5 text-white/80 border-white/10 hover:border-white/30"
            }`}
            style={{
              borderColor: systemState.terminalOpen ? `${cfg.primary}60` : undefined,
              color: systemState.terminalOpen ? cfg.primary : undefined,
            }}
          >
            <Terminal size={13} style={{ color: cfg.primary }} />
            <span className="text-[11px] font-medium">TERMINAL</span>
          </button>

          {/* Scratchpad / Notes */}
          <button
            onClick={() => {
              sfx.playClick();
              onOpenNotes();
            }}
            className="flex items-center justify-center gap-1.5 py-2 px-2 rounded border bg-white/5 text-white/80 border-white/10 hover:border-white/30 transition-all"
          >
            <FileText size={13} style={{ color: cfg.primary }} />
            <span className="text-[11px] font-medium">
              NOTES ({systemState.notes.length})
            </span>
          </button>

          {/* SFX Audio Feedback Toggle */}
          <button
            onClick={() => {
              sfx.enabled = !systemState.soundEffectsEnabled;
              sfx.playClick();
              onUpdateState((s) => ({
                ...s,
                soundEffectsEnabled: !s.soundEffectsEnabled,
              }));
            }}
            className="flex items-center justify-center gap-1.5 py-2 px-2 rounded border bg-white/5 text-white/80 border-white/10 hover:border-white/30 transition-all"
          >
            <Play size={11} style={{ color: cfg.primary }} />
            <span className="text-[11px] font-medium">
              SFX: {systemState.soundEffectsEnabled ? "ON" : "OFF"}
            </span>
          </button>
        </div>
      </div>

      {/* 5. FAST TACTICAL ACTION COMMANDS */}
      <div className="flex flex-col gap-1.5 pt-1 border-t" style={{ borderColor: `${cfg.primary}20` }}>
        <span className="font-mono text-[10px] text-white/50 tracking-wider uppercase">
          QUICK PROTOCOLS
        </span>
        <div className="flex flex-wrap gap-1">
          <button
            onClick={() => {
              sfx.playScan();
              onTriggerCommand("run system diagnostics");
            }}
            className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-[10px] font-mono text-white/80 flex items-center gap-1 transition-all"
          >
            <ShieldAlert size={10} style={{ color: cfg.primary }} />
            DIAGNOSTICS
          </button>

          <button
            onClick={() => {
              sfx.playConfirm();
              onTriggerCommand("set timer for 5 minutes");
            }}
            className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-[10px] font-mono text-white/80 flex items-center gap-1 transition-all"
          >
            <Timer size={10} style={{ color: cfg.primary }} />
            5M TIMER
          </button>

          <button
            onClick={() => {
              sfx.playConfirm();
              onTriggerCommand("open youtube");
            }}
            className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-[10px] font-mono text-white/80 flex items-center gap-1 transition-all"
          >
            <ExternalLink size={10} style={{ color: cfg.primary }} />
            YOUTUBE
          </button>

          <button
            onClick={() => {
              sfx.playConfirm();
              onTriggerCommand("what time is it");
            }}
            className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-[10px] font-mono text-white/80 flex items-center gap-1 transition-all"
          >
            TIME CHECK
          </button>
        </div>
      </div>
    </div>
  );
}
