import React, { useMemo } from "react";
import { Timer as TimerIcon, X } from "lucide-react";
import { ActiveTimer, HudTheme } from "../types";
import { getThemeConfig } from "../utils/themeStyles";
import { sfx } from "../utils/sfx";

interface ActiveTimersHUDProps {
  timers: ActiveTimer[];
  theme: HudTheme;
  onCancelTimer: (id: string) => void;
}

export default function ActiveTimersHUD({ timers, theme, onCancelTimer }: ActiveTimersHUDProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);

  if (timers.length === 0) return null;

  return (
    <div className="absolute top-20 right-6 z-30 flex flex-col gap-2 pointer-events-auto">
      {timers.map((t) => {
        const progress = Math.max(0, (t.remainingSeconds / t.totalSeconds) * 100);
        const mins = Math.floor(t.remainingSeconds / 60)
          .toString()
          .padStart(2, "0");
        const secs = (t.remainingSeconds % 60).toString().padStart(2, "0");
        const isDone = t.remainingSeconds <= 0;

        return (
          <div
            key={t.id}
            className={`flex items-center gap-3 px-3 py-2 rounded-xl border backdrop-blur-md shadow-xl transition-all font-mono select-none ${
              isDone ? "bg-red-500/20 border-red-500 text-red-300 animate-bounce" : "bg-black/80 text-white"
            }`}
            style={{
              borderColor: isDone ? "#ef4444" : `${cfg.primary}60`,
              boxShadow: `0 0 15px ${isDone ? "#ef4444" : cfg.primary}40`,
            }}
          >
            <div className="flex items-center gap-1.5">
              <TimerIcon size={14} className={isDone ? "animate-spin" : ""} style={{ color: cfg.primary }} />
              <div className="flex flex-col">
                <span className="text-[10px] text-white/60 tracking-wider uppercase">{t.label}</span>
                <span className="text-xs font-bold tracking-widest" style={{ color: isDone ? "#ef4444" : cfg.primary }}>
                  {mins}:{secs} {isDone && "TIME UP!"}
                </span>
              </div>
            </div>

            {/* Micro Progress Bar */}
            <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full transition-all duration-1000"
                style={{
                  width: `${progress}%`,
                  backgroundColor: cfg.primary,
                }}
              />
            </div>

            <button
              onClick={() => {
                sfx.playClick();
                onCancelTimer(t.id);
              }}
              className="p-1 hover:bg-white/10 rounded text-white/50 hover:text-white transition-colors"
              title="Dismiss Timer"
            >
              <X size={13} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
