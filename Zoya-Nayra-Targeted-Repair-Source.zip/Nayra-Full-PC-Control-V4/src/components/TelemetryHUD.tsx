import React, { useState, useEffect, useMemo } from "react";
import { Cpu, Zap, Wifi, Activity, ShieldCheck, Clock } from "lucide-react";
import { HudTheme, AppState } from "../types";
import { getThemeConfig } from "../utils/themeStyles";

interface TelemetryHUDProps {
  theme: HudTheme;
  appState: AppState;
  audioLevel: number;
}

export default function TelemetryHUD({ theme, appState, audioLevel }: TelemetryHUDProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);

  // Real-time simulated hardware metrics
  const [cpu, setCpu] = useState(28);
  const [ram, setRam] = useState(34);
  const [cores, setCores] = useState([24, 32, 18, 40]);
  const [battery, setBattery] = useState<{ level: number; charging: boolean }>({ level: 88, charging: true });
  const [ping, setPing] = useState(24);
  const [uptime, setUptime] = useState(0);

  // Uptime tick
  useEffect(() => {
    const timer = setInterval(() => setUptime((u) => u + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // Format uptime HH:MM:SS
  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600).toString().padStart(2, "0");
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  // Battery API
  useEffect(() => {
    if (typeof navigator !== "undefined" && "getBattery" in navigator) {
      (navigator as any).getBattery().then((batt: any) => {
        setBattery({
          level: Math.round(batt.level * 100),
          charging: batt.charging,
        });
        batt.addEventListener("levelchange", () => {
          setBattery((b) => ({ ...b, level: Math.round(batt.level * 100) }));
        });
        batt.addEventListener("chargingchange", () => {
          setBattery((b) => ({ ...b, charging: batt.charging }));
        });
      }).catch(() => {});
    }
  }, []);

  // Hardware fluctuations based on app state
  useEffect(() => {
    const interval = setInterval(() => {
      const isBusy = appState === "processing" || appState === "speaking";
      const baseCpu = isBusy ? 65 : 22;
      const newCpu = Math.min(96, Math.max(12, baseCpu + Math.floor(Math.random() * 20 - 8)));
      setCpu(newCpu);
      setRam(Math.min(85, Math.max(30, 32 + (isBusy ? 14 : 0) + Math.floor(Math.random() * 6))));
      setCores([
        Math.min(99, Math.max(10, newCpu + Math.floor(Math.random() * 16 - 8))),
        Math.min(99, Math.max(10, newCpu + Math.floor(Math.random() * 16 - 8))),
        Math.min(99, Math.max(10, newCpu + Math.floor(Math.random() * 16 - 8))),
        Math.min(99, Math.max(10, newCpu + Math.floor(Math.random() * 16 - 8))),
      ]);
      setPing(Math.max(14, 22 + Math.floor(Math.random() * 12 - 5)));
    }, 2200);

    return () => clearInterval(interval);
  }, [appState]);

  return (
    <div 
      className="flex flex-col gap-3.5 p-4 rounded-xl border backdrop-blur-md transition-all duration-300 w-full max-w-[300px] select-none"
      style={{
        backgroundColor: "rgba(2, 7, 13, 0.75)",
        borderColor: `${cfg.primary}35`,
        boxShadow: `0 0 20px ${cfg.primary}15`,
      }}
    >
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${cfg.primary}30` }}>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: cfg.primary }} />
          <span className="font-mono text-xs tracking-wider uppercase font-bold" style={{ color: cfg.primary }}>
            SYS.TELEMETRY // HUD
          </span>
        </div>
        <span className="font-mono text-[10px] tracking-widest text-white/50">NODE-01</span>
      </div>

      {/* CPU & Core Load */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-white/70 flex items-center gap-1.5">
            <Cpu size={13} style={{ color: cfg.primary }} /> CPU LOAD
          </span>
          <span className="font-bold" style={{ color: cfg.primary }}>
            {cpu}%
          </span>
        </div>
        
        {/* Main CPU Progress Bar */}
        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
          <div
            className="h-full transition-all duration-500 rounded-full"
            style={{
              width: `${cpu}%`,
              backgroundColor: cfg.primary,
              boxShadow: `0 0 8px ${cfg.primary}`,
            }}
          />
        </div>

        {/* 4 Multi-Core Indicators */}
        <div className="grid grid-cols-4 gap-1.5 pt-1">
          {cores.map((load, idx) => (
            <div key={idx} className="flex flex-col items-center bg-white/5 p-1 rounded border border-white/5">
              <span className="text-[8px] font-mono text-white/40">C{idx}</span>
              <span className="text-[10px] font-mono font-semibold" style={{ color: cfg.primary }}>
                {load}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Memory / RAM */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-white/70 flex items-center gap-1.5">
            <Activity size={13} style={{ color: cfg.primary }} /> RAM ALLOC
          </span>
          <span className="font-bold" style={{ color: cfg.primary }}>
            {(2.4 + (ram * 0.04)).toFixed(2)} GB / 8 GB ({ram}%)
          </span>
        </div>
        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
          <div
            className="h-full transition-all duration-500 rounded-full"
            style={{
              width: `${ram}%`,
              backgroundColor: cfg.accent,
              boxShadow: `0 0 6px ${cfg.accent}`,
            }}
          />
        </div>
      </div>

      {/* Power / Battery */}
      <div className="flex items-center justify-between font-mono text-xs bg-white/5 p-2 rounded-lg border border-white/5">
        <span className="text-white/70 flex items-center gap-1.5">
          <Zap size={13} style={{ color: cfg.primary }} /> POWER GRID
        </span>
        <div className="flex items-center gap-1.5 font-bold" style={{ color: cfg.primary }}>
          <span>{battery.level}%</span>
          {battery.charging && <span className="text-[9px] text-green-400 font-semibold">[PWR CHG]</span>}
        </div>
      </div>

      {/* Network Latency & Ping */}
      <div className="flex items-center justify-between font-mono text-xs bg-white/5 p-2 rounded-lg border border-white/5">
        <span className="text-white/70 flex items-center gap-1.5">
          <Wifi size={13} style={{ color: cfg.primary }} /> UPLINK LINK
        </span>
        <span className="font-bold font-mono text-[11px]" style={{ color: cfg.primary }}>
          {ping} ms <span className="text-[9px] text-emerald-400 font-semibold">[STABLE]</span>
        </span>
      </div>

      {/* Audio Input Sensitivity Level */}
      <div className="flex flex-col gap-1 font-mono text-[11px]">
        <div className="flex justify-between text-white/60">
          <span>AUDIO SENSOR</span>
          <span style={{ color: cfg.primary }}>{audioLevel > 0 ? `${audioLevel}% INPUT` : "STANDBY"}</span>
        </div>
        <div className="grid grid-cols-12 gap-0.5 h-1.5">
          {Array.from({ length: 12 }).map((_, i) => {
            const isActive = audioLevel > i * 8;
            return (
              <div
                key={i}
                className="h-full rounded-xs transition-colors duration-150"
                style={{
                  backgroundColor: isActive ? cfg.primary : "rgba(255,255,255,0.08)",
                  boxShadow: isActive ? `0 0 4px ${cfg.primary}` : "none",
                }}
              />
            );
          })}
        </div>
      </div>

      {/* System Uptime & Security Badge */}
      <div className="pt-2 border-t flex items-center justify-between font-mono text-[10px]" style={{ borderColor: `${cfg.primary}20` }}>
        <span className="text-white/50 flex items-center gap-1">
          <Clock size={11} /> UPTIME {formatUptime(uptime)}
        </span>
        <span className="flex items-center gap-1 font-semibold" style={{ color: cfg.primary }}>
          <ShieldCheck size={11} /> AES-256 SECURE
        </span>
      </div>
    </div>
  );
}
