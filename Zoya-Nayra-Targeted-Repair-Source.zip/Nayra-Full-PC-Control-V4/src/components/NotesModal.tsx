import React, { useState, useMemo } from "react";
import { X, Plus, Trash2, FileText, Check } from "lucide-react";
import { HudTheme } from "../types";
import { getThemeConfig } from "../utils/themeStyles";
import { sfx } from "../utils/sfx";

interface NotesModalProps {
  theme: HudTheme;
  notes: string[];
  onAddNote: (text: string) => void;
  onDeleteNote: (index: number) => void;
  onClearNotes: () => void;
  onClose: () => void;
}

export default function NotesModal({
  theme,
  notes,
  onAddNote,
  onDeleteNote,
  onClearNotes,
  onClose,
}: NotesModalProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);
  const [inputText, setInputText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sfx.playConfirm();
    onAddNote(inputText.trim());
    setInputText("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4">
      <div
        className="relative w-full max-w-md rounded-2xl border p-5 flex flex-col gap-3 shadow-2xl backdrop-blur-xl overflow-hidden max-h-[85vh]"
        style={{
          backgroundColor: "rgba(2, 7, 13, 0.95)",
          borderColor: `${cfg.primary}60`,
          boxShadow: `0 0 40px ${cfg.primary}30`,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${cfg.primary}30` }}>
          <div className="flex items-center gap-2">
            <FileText size={16} style={{ color: cfg.primary }} />
            <span className="font-mono text-sm tracking-widest font-bold uppercase" style={{ color: cfg.primary }}>
              SECURE SCRATCHPAD // PROTOCOL MEMORY
            </span>
          </div>
          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="p-1 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Record memo or protocol note..."
            className="flex-1 px-3 py-2 bg-white/5 border rounded-lg text-sm font-mono text-white outline-none placeholder:text-white/30 focus:border-cyan-400 transition-colors"
            style={{ borderColor: `${cfg.primary}40` }}
            autoFocus
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-4 py-2 rounded-lg font-mono text-xs font-bold uppercase flex items-center gap-1 transition-all disabled:opacity-40"
            style={{
              backgroundColor: `${cfg.primary}25`,
              color: cfg.primary,
              border: `1px solid ${cfg.primary}60`,
            }}
          >
            <Plus size={14} /> ADD
          </button>
        </form>

        {/* Notes List */}
        <div className="flex-1 overflow-y-auto max-h-[340px] flex flex-col gap-2 pr-1 hud-scrollbar">
          {notes.length === 0 ? (
            <div className="text-center py-10 text-white/40 font-mono text-xs italic">
              No protocol notes logged. Say "take note: [content]" or type above.
            </div>
          ) : (
            notes.map((note, index) => (
              <div
                key={index}
                className="flex items-start justify-between gap-2 p-2.5 rounded-lg border bg-white/5 font-mono text-xs text-white/90 group"
                style={{ borderColor: `${cfg.primary}25` }}
              >
                <div className="flex items-start gap-2 flex-1">
                  <Check size={13} className="mt-0.5 shrink-0" style={{ color: cfg.primary }} />
                  <span className="break-words">{note}</span>
                </div>
                <button
                  onClick={() => {
                    sfx.playClick();
                    onDeleteNote(index);
                  }}
                  className="p-1 text-white/40 hover:text-red-400 transition-colors"
                  title="Delete Note"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {notes.length > 0 && (
          <div className="flex items-center justify-between border-t pt-2" style={{ borderColor: `${cfg.primary}20` }}>
            <span className="font-mono text-[10px] text-white/50">{notes.length} LOGGED ITEMS</span>
            <button
              onClick={() => {
                sfx.playClick();
                onClearNotes();
              }}
              className="font-mono text-[10px] text-red-400/80 hover:text-red-400 hover:underline"
            >
              CLEAR ALL
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
