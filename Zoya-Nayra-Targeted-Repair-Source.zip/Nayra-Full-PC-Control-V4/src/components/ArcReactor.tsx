import React, { useMemo } from "react";
import { motion } from "motion/react";
import { AppState, HudTheme } from "../types";
import { getThemeConfig } from "../utils/themeStyles";

interface ArcReactorProps {
  state: AppState;
  theme: HudTheme;
  onClick?: () => void;
  audioLevel?: number; // 0 to 100
}

export default function ArcReactor({ state, theme, onClick, audioLevel = 0 }: ArcReactorProps) {
  const cfg = useMemo(() => getThemeConfig(theme), [theme]);

  // Dynamic animations based on state
  const getRingSpeed = (base: number) => {
    switch (state) {
      case "listening":
        return base * 0.4;
      case "processing":
        return base * 0.2;
      case "speaking":
        return base * 0.5;
      default:
        return base;
    }
  };

  const pulseScale = () => {
    const boost = (audioLevel / 100) * 0.1;
    if (state === "speaking") {
      return [1 + boost, 1.06 + boost, 0.98, 1.04 + boost, 1];
    }
    if (state === "listening") {
      return [1, 1.03 + boost, 1];
    }
    if (state === "processing") {
      return [0.97, 1.03, 0.97];
    }
    return [1, 1.015, 1];
  };

  // Degrees labels for outer telemetry ring
  const degreeLabels = ["000°", "045°", "090°", "135°", "180°", "225°", "270°", "315°"];

  return (
    <div 
      onClick={onClick}
      className="relative w-[320px] h-[320px] sm:w-[420px] sm:h-[420px] md:w-[480px] md:h-[480px] lg:w-[540px] lg:h-[540px] flex items-center justify-center select-none cursor-pointer group"
      title="ZOYA Core Arc Reactor - Click to Toggle Voice Session"
    >
      {/* Dynamic Ambient Core Glow */}
      <motion.div
        animate={{
          scale: pulseScale(),
          opacity: state === "idle" ? [0.25, 0.4, 0.25] : [0.5, 0.85, 0.5],
        }}
        transition={{ duration: state === "idle" ? 4 : 1, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[75%] h-[75%] rounded-full blur-[70px] pointer-events-none"
        style={{ backgroundColor: cfg.primary }}
      />

      {/* Outer Telemetry Compass Ring (0° - 360°) */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: getRingSpeed(80), repeat: Infinity, ease: "linear" }}
        className="absolute inset-0 rounded-full border border-cyan-500/15 pointer-events-none flex items-center justify-center"
        style={{ borderColor: `${cfg.primary}25` }}
      >
        {degreeLabels.map((deg, i) => {
          const angle = i * 45;
          return (
            <div
              key={deg}
              className="absolute text-[9px] font-mono tracking-widest uppercase"
              style={{
                color: cfg.primary,
                opacity: 0.6,
                transform: `rotate(${angle}deg) translateY(-${50}%) rotate(-${angle}deg)`,
                top: "3%",
              }}
            >
              {deg}
            </div>
          );
        })}
      </motion.div>

      {/* Ring 1: Outer Tech Ticks Ring (Rotating Reverse) */}
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: getRingSpeed(50), repeat: Infinity, ease: "linear" }}
        className="absolute w-[92%] h-[92%] rounded-full border border-dashed pointer-events-none"
        style={{ borderColor: `${cfg.primary}40` }}
      />

      {/* Ring 2: Segmented Arc Shield Ring */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: getRingSpeed(35), repeat: Infinity, ease: "linear" }}
        className="absolute w-[80%] h-[80%] rounded-full pointer-events-none"
        style={{
          border: `2px solid ${cfg.primary}50`,
          borderLeftColor: "transparent",
          borderRightColor: "transparent",
        }}
      />

      {/* Ring 3: Radial Frequency Spoke Ticks */}
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: getRingSpeed(60), repeat: Infinity, ease: "linear" }}
        className="absolute w-[68%] h-[68%] rounded-full border border-dotted pointer-events-none"
        style={{ borderColor: `${cfg.primary}60` }}
      />

      {/* Ring 4: Inner Heavy Armor Ring with Crosshairs */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: getRingSpeed(25), repeat: Infinity, ease: "linear" }}
        className="absolute w-[56%] h-[56%] rounded-full pointer-events-none flex items-center justify-center"
        style={{
          border: `1.5px dashed ${cfg.primary}70`,
        }}
      >
        {/* Subtle Crosshairs */}
        <div className="absolute w-full h-[1px] bg-cyan-400/20" style={{ backgroundColor: `${cfg.primary}30` }} />
        <div className="absolute h-full w-[1px] bg-cyan-400/20" style={{ backgroundColor: `${cfg.primary}30` }} />
      </motion.div>

      {/* Ring 5: Fast Inner Quantum Pulse Ring */}
      <motion.div
        animate={{
          rotate: state === "processing" ? 720 : -360,
          scale: pulseScale(),
        }}
        transition={{
          rotate: { duration: getRingSpeed(15), repeat: Infinity, ease: "linear" },
          scale: { duration: 0.6, repeat: Infinity, ease: "easeInOut" },
        }}
        className="absolute w-[44%] h-[44%] rounded-full pointer-events-none"
        style={{
          border: `2px solid ${cfg.primary}`,
          borderTopColor: "transparent",
          borderBottomColor: "transparent",
          boxShadow: `0 0 15px ${cfg.primary}60`,
        }}
      />

      {/* CORE ARC REACTOR CONTAINER */}
      <motion.div
        animate={{ scale: pulseScale() }}
        transition={{ duration: 0.5, repeat: Infinity, ease: "easeInOut" }}
        className="relative w-[34%] h-[34%] rounded-full flex flex-col items-center justify-center backdrop-blur-xl border border-white/20 transition-all duration-300 group-hover:scale-105"
        style={{
          background: `radial-gradient(circle, ${cfg.primary}25 0%, rgba(2, 7, 13, 0.95) 75%)`,
          boxShadow: cfg.glowBoxShadow,
          borderColor: `${cfg.primary}90`,
        }}
      >
        {/* Rotating Core Turbine Blades */}
        <motion.div
          animate={{ rotate: state === "processing" ? 360 : 180 }}
          transition={{ duration: getRingSpeed(10), repeat: Infinity, ease: "linear" }}
          className="absolute inset-2 rounded-full border border-dashed pointer-events-none opacity-40"
          style={{ borderColor: cfg.primary }}
        />

        {/* AI Core Brand Title */}
        <div className="flex flex-col items-center justify-center text-center z-10 px-2">
          <span 
            className="font-mono text-[8px] sm:text-[9px] tracking-[0.35em] uppercase opacity-75 font-semibold"
            style={{ color: cfg.primary }}
          >
            SYS.CORE
          </span>
          <h1 
            className="font-bold tracking-[0.25em] text-xl sm:text-2xl md:text-3xl text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]"
            style={{ textShadow: `0 0 16px ${cfg.primary}, 0 0 30px ${cfg.primary}` }}
          >
            ZOYA
          </h1>
          <span
            className="font-mono text-[7px] sm:text-[8px] tracking-[0.2em] font-medium uppercase mt-0.5 px-1.5 py-0.5 rounded border"
            style={{
              color: cfg.primary,
              borderColor: `${cfg.primary}40`,
              backgroundColor: `${cfg.primary}15`,
            }}
          >
            {state === "listening" && "LISTENING..."}
            {state === "processing" && "COMPUTING..."}
            {state === "speaking" && "VOCALIZING"}
            {state === "idle" && "ONLINE // READY"}
          </span>
        </div>
      </motion.div>
    </div>
  );
}
