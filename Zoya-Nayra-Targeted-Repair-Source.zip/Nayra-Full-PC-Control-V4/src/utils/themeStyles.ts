import { HudTheme } from "../types";

export interface ThemeConfig {
  name: string;
  gridClass: string;
  primary: string;
  primaryBg: string;
  accent: string;
  glow: string;
  border: string;
  borderDotted: string;
  borderDashed: string;
  textPrimary: string;
  textSecondary: string;
  badgeBg: string;
  coreHex: string;
  glowBoxShadow: string;
}

export function getThemeConfig(theme: HudTheme): ThemeConfig {
  switch (theme) {
    case "red_alert":
      return {
        name: "RED ALERT",
        gridClass: "hud-grid-red",
        primary: "#ef4444",
        primaryBg: "rgba(239, 68, 68, 0.1)",
        accent: "#f97316",
        glow: "shadow-[0_0_25px_rgba(239,68,68,0.5)]",
        border: "border-red-500/50",
        borderDotted: "border-red-500/40",
        borderDashed: "border-red-500/30",
        textPrimary: "text-red-400",
        textSecondary: "text-red-300/70",
        badgeBg: "bg-red-500/20 text-red-300 border-red-500/40",
        coreHex: "#ef4444",
        glowBoxShadow: "0 0 35px rgba(239, 68, 68, 0.6), inset 0 0 25px rgba(239, 68, 68, 0.4)",
      };
    case "tactical_amber":
      return {
        name: "TACTICAL AMBER",
        gridClass: "hud-grid-amber",
        primary: "#f59e0b",
        primaryBg: "rgba(245, 158, 11, 0.1)",
        accent: "#fbbf24",
        glow: "shadow-[0_0_25px_rgba(245,158,11,0.5)]",
        border: "border-amber-500/50",
        borderDotted: "border-amber-500/40",
        borderDashed: "border-amber-500/30",
        textPrimary: "text-amber-400",
        textSecondary: "text-amber-300/70",
        badgeBg: "bg-amber-500/20 text-amber-300 border-amber-500/40",
        coreHex: "#f59e0b",
        glowBoxShadow: "0 0 35px rgba(245, 158, 11, 0.6), inset 0 0 25px rgba(245, 158, 11, 0.4)",
      };
    case "matrix_green":
      return {
        name: "MATRIX EMERALD",
        gridClass: "hud-grid-green",
        primary: "#22c55e",
        primaryBg: "rgba(34, 197, 94, 0.1)",
        accent: "#4ade80",
        glow: "shadow-[0_0_25px_rgba(34,197,94,0.5)]",
        border: "border-green-500/50",
        borderDotted: "border-green-500/40",
        borderDashed: "border-green-500/30",
        textPrimary: "text-green-400",
        textSecondary: "text-green-300/70",
        badgeBg: "bg-green-500/20 text-green-300 border-green-500/40",
        coreHex: "#22c55e",
        glowBoxShadow: "0 0 35px rgba(34, 197, 94, 0.6), inset 0 0 25px rgba(34, 197, 94, 0.4)",
      };
    case "cyan":
    default:
      return {
        name: "CYAN PRIME",
        gridClass: "hud-grid",
        primary: "#00f0ff",
        primaryBg: "rgba(0, 240, 255, 0.08)",
        accent: "#38bdf8",
        glow: "shadow-[0_0_25px_rgba(0,240,255,0.5)]",
        border: "border-cyan-500/40",
        borderDotted: "border-cyan-500/30",
        borderDashed: "border-cyan-500/25",
        textPrimary: "text-cyan-400",
        textSecondary: "text-cyan-300/70",
        badgeBg: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
        coreHex: "#00f0ff",
        glowBoxShadow: "0 0 40px rgba(0, 240, 255, 0.6), inset 0 0 30px rgba(0, 240, 255, 0.35)",
      };
  }
}
