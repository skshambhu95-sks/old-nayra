import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { 
  Mic, 
  MicOff, 
  Loader2, 
  Volume2, 
  VolumeX, 
  Send, 
  Trash2, 
  Sliders, 
  Terminal as TerminalIcon, 
  Maximize2, 
  Minimize2, 
  Activity, 
  Zap, 
  ShieldAlert,
  FileText
} from "lucide-react";
import { getZoyaResponse, getZoyaAudio, resetZoyaSession } from "./services/geminiService";
import { processCommand, SystemActionPayload } from "./services/commandService";
import { LiveSessionManager } from "./services/liveService";
import ArcReactor from "./components/ArcReactor";
import TelemetryHUD from "./components/TelemetryHUD";
import SystemControlPanel from "./components/SystemControlPanel";
import CameraHUDModal from "./components/CameraHUDModal";
import TerminalLog, { LogEntry } from "./components/TerminalLog";
import NotesModal from "./components/NotesModal";
import ActiveTimersHUD from "./components/ActiveTimersHUD";
import PermissionModal from "./components/PermissionModal";
import { playPCM } from "./utils/audioUtils";
import { sfx } from "./utils/sfx";
import { getThemeConfig } from "./utils/themeStyles";
import { AppState, ChatMessage, SystemControlState } from "./types";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [appState, setAppState] = useState<AppState>("idle");

  // System Controls State
  const [systemState, setSystemState] = useState<SystemControlState>(() => {
    const saved = localStorage.getItem("zoya_system_state");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          volume: parsed.volume ?? 80,
          brightness: parsed.brightness ?? 100,
          isMuted: parsed.isMuted ?? false,
          theme: parsed.theme ?? "cyan",
          cameraActive: false,
          terminalOpen: false,
          soundEffectsEnabled: parsed.soundEffectsEnabled ?? true,
          notes: parsed.notes ?? ["Review telemetry feed", "Calibrate Stark core reactor"],
          activeTimers: [],
        };
      } catch {
        // Fallback
      }
    }
    return {
      volume: 80,
      brightness: 100,
      isMuted: false,
      theme: "cyan",
      cameraActive: false,
      terminalOpen: false,
      soundEffectsEnabled: true,
      notes: ["Review telemetry feed", "Calibrate Stark core reactor"],
      activeTimers: [],
    };
  });

  // Save system state changes
  useEffect(() => {
    localStorage.setItem(
      "zoya_system_state",
      JSON.stringify({
        volume: systemState.volume,
        brightness: systemState.brightness,
        isMuted: systemState.isMuted,
        theme: systemState.theme,
        soundEffectsEnabled: systemState.soundEffectsEnabled,
        notes: systemState.notes,
      })
    );
  }, [systemState.volume, systemState.brightness, systemState.isMuted, systemState.theme, systemState.soundEffectsEnabled, systemState.notes]);

  const cfg = useMemo(() => getThemeConfig(systemState.theme), [systemState.theme]);

  // Chat messages
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("zoya_chat_history");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse chat history", e);
      }
    }
    return [
      {
        id: "init-1",
        sender: "zoya",
        text: "Zoya online. Stark-level holographic telemetry active. All systems ready for your command, Ashwani!",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ];
  });
  const messagesRef = useRef(messages);
  useEffect(() => {
    messagesRef.current = messages;
    localStorage.setItem("zoya_chat_history", JSON.stringify(messages));
  }, [messages]);

  // Terminal logs
  const [terminalLogs, setTerminalLogs] = useState<LogEntry[]>([
    { id: "1", time: "00:00:01", type: "SYS", message: "KERNEL_INIT // MATRIX V4.8 LOADED" },
    { id: "2", time: "00:00:02", type: "AUDIO", message: "AUDIO_SYNTH: KORE MODEL CALIBRATED" },
    { id: "3", time: "00:00:03", type: "AI", message: "NEURAL_NET: ZOYA COGNITIVE RUNTIME READY" },
  ]);

  const addLog = useCallback((type: LogEntry["type"], message: string) => {
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setTerminalLogs((prev) => [...prev.slice(-80), { id: Date.now().toString(), time, type, message }]);
  }, []);

  // UI state
  const [textInput, setTextInput] = useState("");
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);

  const liveSessionRef = useRef<LiveSessionManager | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync mute with live session
  useEffect(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.isMuted = systemState.isMuted;
    }
  }, [systemState.isMuted]);

  // Audio level simulation during speaking or listening
  useEffect(() => {
    let interval: any = null;
    if (appState === "speaking" || appState === "listening") {
      interval = setInterval(() => {
        setAudioLevel(Math.floor(Math.random() * 65 + 30));
      }, 150);
    } else {
      setAudioLevel(0);
    }
    return () => clearInterval(interval);
  }, [appState]);

  // Active timers countdown tick
  useEffect(() => {
    const timer = setInterval(() => {
      setSystemState((prev) => {
        if (prev.activeTimers.length === 0) return prev;
        let playedAlert = false;
        const updated = prev.activeTimers.map((t) => {
          if (!t.active || t.remainingSeconds <= 0) return t;
          const nextSec = t.remainingSeconds - 1;
          if (nextSec <= 0 && !playedAlert) {
            sfx.playTimerBeep();
            playedAlert = true;
            addLog("SYS", `TIMER COMPLETED: ${t.label}`);
          }
          return { ...t, remainingSeconds: nextSec };
        });
        return { ...prev, activeTimers: updated };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [addLog]);

  // Execute system or browser action
  const executeActionPayload = useCallback(
    (payload: SystemActionPayload) => {
      addLog("CMD", `EXEC: ${payload.type} -> ${payload.actionText}`);

      switch (payload.type) {
        case "SET_VOLUME":
          if (typeof payload.value === "number") {
            setSystemState((s) => ({ ...s, volume: payload.value, isMuted: false }));
          } else if (payload.value === "+15") {
            setSystemState((s) => ({ ...s, volume: Math.min(100, s.volume + 15), isMuted: false }));
          } else if (payload.value === "-15") {
            setSystemState((s) => ({ ...s, volume: Math.max(0, s.volume - 15) }));
          }
          sfx.playConfirm();
          break;

        case "SET_BRIGHTNESS":
          if (typeof payload.value === "number") {
            setSystemState((s) => ({ ...s, brightness: payload.value }));
          }
          sfx.playConfirm();
          break;

        case "SET_THEME":
          setSystemState((s) => ({ ...s, theme: payload.value }));
          if (payload.value === "red_alert") {
            sfx.playAlert();
          } else {
            sfx.playConfirm();
          }
          break;

        case "TOGGLE_MUTE":
          setSystemState((s) => ({ ...s, isMuted: payload.value }));
          sfx.playClick();
          break;

        case "RUN_DIAGNOSTICS":
          sfx.playScan();
          addLog("SYS", "DIAGNOSTICS: CORE_VOLTAGE: 1.18V // NOMINAL");
          addLog("SYS", "DIAGNOSTICS: QUANTUM_DECOHERENCE: 0.002% // PASS");
          addLog("SYS", "DIAGNOSTICS: THERMAL_MATRIX: 38.4°C // OPTIMAL");
          break;

        case "TOGGLE_CAMERA":
          setSystemState((s) => ({ ...s, cameraActive: !!payload.value }));
          sfx.playClick();
          break;

        case "SET_TIMER":
          if (payload.value) {
            setSystemState((s) => ({
              ...s,
              activeTimers: [
                ...s.activeTimers,
                {
                  id: Date.now().toString(),
                  label: payload.value.label,
                  totalSeconds: payload.value.seconds,
                  remainingSeconds: payload.value.seconds,
                  active: true,
                },
              ],
            }));
            sfx.playConfirm();
          }
          break;

        case "ADD_NOTE":
          if (payload.value) {
            setSystemState((s) => ({
              ...s,
              notes: [payload.value, ...s.notes],
            }));
            sfx.playConfirm();
          }
          break;

        case "CLEAR_NOTES":
          setSystemState((s) => ({ ...s, notes: [] }));
          sfx.playClick();
          break;

        case "CLEAR_HISTORY":
          setMessages([]);
          resetZoyaSession();
          sfx.playClick();
          break;

        case "TOGGLE_FULLSCREEN":
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
            setIsFullscreen(true);
          } else {
            document.exitFullscreen().catch(() => {});
            setIsFullscreen(false);
          }
          sfx.playClick();
          break;

        case "BROWSER_ACTION":
          if (payload.url) {
            sfx.playConfirm();
            setTimeout(() => {
              window.open(payload.url, "_blank");
            }, 1200);
          }
          break;

        case "PC_ACTION":
          sfx.playConfirm();
          fetch("http://127.0.0.1:3210/api/execute", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload.value),
          })
            .then((r) => r.json())
            .then((result) => addLog(result.ok ? "SYS" : "ERR", result.message || "Local agent response received"))
            .catch(() => addLog("ERR", "Local Nayra Agent is not running. Start: npm run agent"));
          break;

        default:
          break;
      }
    },
    [addLog]
  );

  // Command handler (Text or voice input)
  const handleCommand = useCallback(
    async (rawInput: string) => {
      const input = rawInput.trim();
      if (!input) return;

      const userTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setMessages((prev) => [...prev, { id: Date.now().toString(), sender: "user", text: input, timestamp: userTime }]);
      addLog("CMD", `USER: "${input}"`);

      // If active Live session, dispatch through live session
      if (isSessionActive && liveSessionRef.current) {
        liveSessionRef.current.sendText(input);
        return;
      }

      setAppState("processing");

      // Route likely real-world commands to the local Windows agent. The agent has its own
      // AI planner/vision fallback, so commands are not limited to a fixed keyword list.
      const localTask = /\b(open|khol|kholo|start|launch|close|band|likh|likho|write|type|paste|create|banao|bana|build|make|website|web|code|coding|file|folder|youtube|song|gana|play|pause|stop|whatsapp|message|massage|send|print|shutdown|restart|lock|unlock|search|find|click|press|scroll|download|upload|move|copy|delete|rename|save|minimize|maximize|switch|select|screenshot|screen|desktop|app|application|remind|reminder|yaad|schedule|set|volume|mute|calculator|notepad|explorer|chrome|browser|vs\s*code)\b/i.test(input) || /\b(kar|karo|do|de|bhej|bhejo|bajao|chalao|kholo|banao|likho|dikhao|yaad|band)\b/i.test(input);
      if (localTask) {
        try {
          const controller = new AbortController();
          const timeout = window.setTimeout(() => controller.abort(), 45000);
          const r = await fetch("http://127.0.0.1:3210/api/execute", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ command: input }), signal: controller.signal
          });
          window.clearTimeout(timeout);
          const result = await r.json().catch(() => ({}));
          if (result.ok) {
            const responseText = String(result.message || "Done.");
            const zoyaTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
            setMessages((prev) => [...prev, { id: Date.now().toString() + "-z", sender: "zoya", text: responseText, timestamp: zoyaTime }]);
            addLog("SYS", `LOCAL ACTION: ${responseText}`);
            if (!systemState.isMuted && systemState.volume > 0) {
              setAppState("speaking");
              const audioBase64 = await getZoyaAudio(responseText);
              if (audioBase64) await playPCM(audioBase64, systemState.volume / 100);
            }
            setAppState("idle");
            return;
          }
          addLog("WARN", result.message || "Local agent could not complete the task; using AI fallback.");
        } catch (error) {
          addLog("WARN", error instanceof DOMException && error.name === "AbortError" ? "Local action timed out; using AI fallback." : "Local agent unavailable; using AI fallback.");
        }
      }

      // Check legacy HUD/system mappings
      const commandResult = processCommand(input);

      let responseText = "";

      if (commandResult.actionText) {
        responseText = commandResult.actionText;
        executeActionPayload(commandResult);

        const zoyaTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString() + "-z", sender: "zoya", text: responseText, timestamp: zoyaTime },
        ]);
        addLog("AI", `ZOYA: "${responseText}"`);

        if (!systemState.isMuted && systemState.volume > 0) {
          setAppState("speaking");
          const audioBase64 = await getZoyaAudio(responseText);
          if (audioBase64) {
            await playPCM(audioBase64, systemState.volume / 100);
          }
        }
        setAppState("idle");
      } else {
        // Conversational AI chit-chat
        responseText = await getZoyaResponse(input, messagesRef.current);
        const zoyaTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString() + "-z", sender: "zoya", text: responseText, timestamp: zoyaTime },
        ]);
        addLog("AI", `ZOYA: "${responseText}"`);

        if (!systemState.isMuted && systemState.volume > 0) {
          setAppState("speaking");
          const audioBase64 = await getZoyaAudio(responseText);
          if (audioBase64) {
            await playPCM(audioBase64, systemState.volume / 100);
          }
        }
        setAppState("idle");
      }
    },
    [isSessionActive, executeActionPayload, systemState.isMuted, systemState.volume, addLog]
  );

  // Toggle Live Audio Voice Session
  const toggleListening = async () => {
    sfx.playClick();

    if (isSessionActive) {
      setIsSessionActive(false);
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
        liveSessionRef.current = null;
      }
      setAppState("idle");
      addLog("SYS", "VOCAL SESSION TERMINATED // MEMORY PRESERVED");
    } else {
      try {
        setIsSessionActive(true);
        resetZoyaSession();

        const persistentMemory = messagesRef.current.slice(-30).map(m => `${m.sender}: ${m.text}`).join("\n");
        const session = new LiveSessionManager(persistentMemory);
        session.isMuted = systemState.isMuted;
        liveSessionRef.current = session;

        session.onStateChange = (state) => {
          setAppState(state);
        };

        session.onConnectionLost = (reason) => {
          setIsSessionActive(false);
          liveSessionRef.current = null;
          setAppState("idle");
          addLog("ERR", `${reason || "Voice session lost"}. Conversation memory preserved.`);
        };

        session.onMessage = (sender, text) => {
          const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
          setMessages((prev) => [...prev, { id: Date.now().toString() + "-" + sender, sender, text, timestamp: time }]);
          addLog(sender === "user" ? "CMD" : "AI", `${sender.toUpperCase()}: "${text}"`);
        };

        session.onCommand = (url) => {
          addLog("SYS", `BROWSER REQUEST: ${url}`);
          sfx.playConfirm();
        };

        session.onSystemAction = async (action) => {
          addLog("SYS", `SYSTEM_ACTION: ${action.type}`);
          if (action.type === "PC_ACTION") {
            const command = String(action.value?.command || action.text || "").trim();
            if (!command) return "No PC command was supplied.";
            addLog("CMD", `EXEC: PC_ACTION -> ${command}`);
            try {
              const response = await fetch("http://127.0.0.1:3210/api/execute", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ command }),
              });
              const result = await response.json().catch(() => ({}));
              const message = String(result.message || (response.ok ? "PC command completed." : "PC command failed."));
              addLog(response.ok ? "SYS" : "ERR", message);
              return message;
            } catch {
              const message = "Local Nayra Agent is not running. Start: npm run agent";
              addLog("ERR", message);
              return message;
            }
          }
          if (action.type === "SCREEN_CONTEXT") {
            try {
              const response = await fetch("http://127.0.0.1:3210/api/execute", {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ command: "inspect my screen" })
              });
              const result = await response.json().catch(() => ({}));
              addLog(response.ok ? "SYS" : "ERR", String(result.message || "Screen inspection failed."));
              return String(result.message || "Screen inspection failed.");
            } catch {
              return "Local agent is not running, so I cannot inspect the Windows screen.";
            }
          }
          const parsed = processCommand(`${action.type} ${action.value || ""}`);
          if (parsed.type !== "NONE") executeActionPayload(parsed);
          return "System action completed.";
        };

        await session.start();
        addLog("SYS", "VOCAL SESSION ESTABLISHED // LISTENING");
      } catch (e) {
        console.error("Failed to start session", e);
        setShowPermissionModal(true);
        setIsSessionActive(false);
        setAppState("idle");
        addLog("WARN", "MICROPHONE PERMISSION DENIED");
      }
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    handleCommand(textInput);
    setTextInput("");
  };

  const latestMessage = messages[messages.length - 1];

  return (
    <div
      className={`h-[100dvh] w-screen bg-[#02070d] text-white flex flex-col items-center justify-between font-sans relative overflow-hidden m-0 p-0 ${cfg.gridClass}`}
      style={{
        filter: `brightness(${systemState.brightness}%)`,
      }}
    >
      {/* Scanline CRT overlay for authenticity */}
      <div className="absolute inset-0 hud-scanlines pointer-events-none z-1" />

      {/* Red alert ambient emergency pulse */}
      {systemState.theme === "red_alert" && (
        <div className="absolute inset-0 bg-red-600/10 pointer-events-none animate-pulse z-1" />
      )}

      {/* MODALS */}
      {showPermissionModal && <PermissionModal onClose={() => setShowPermissionModal(false)} />}
      {systemState.cameraActive && (
        <CameraHUDModal
          theme={systemState.theme}
          onClose={() => setSystemState((s) => ({ ...s, cameraActive: false }))}
        />
      )}
      {showNotesModal && (
        <NotesModal
          theme={systemState.theme}
          notes={systemState.notes}
          onAddNote={(text) => setSystemState((s) => ({ ...s, notes: [text, ...s.notes] }))}
          onDeleteNote={(idx) =>
            setSystemState((s) => ({ ...s, notes: s.notes.filter((_, i) => i !== idx) }))
          }
          onClearNotes={() => setSystemState((s) => ({ ...s, notes: [] }))}
          onClose={() => setShowNotesModal(false)}
        />
      )}
      {systemState.terminalOpen && (
        <TerminalLog
          theme={systemState.theme}
          logs={terminalLogs}
          onClear={() => setTerminalLogs([])}
          onClose={() => setSystemState((s) => ({ ...s, terminalOpen: false }))}
        />
      )}

      {/* Active Timers Countdown Widget */}
      <ActiveTimersHUD
        timers={systemState.activeTimers}
        theme={systemState.theme}
        onCancelTimer={(id) =>
          setSystemState((s) => ({
            ...s,
            activeTimers: s.activeTimers.filter((t) => t.id !== id),
          }))
        }
      />

      {/* ================= TOP HUD HEADER ================= */}
      <header
        className="w-full flex justify-between items-center z-20 px-4 py-3 md:px-8 md:py-3.5 border-b backdrop-blur-md"
        style={{
          backgroundColor: "rgba(2, 7, 13, 0.8)",
          borderColor: `${cfg.primary}30`,
        }}
      >
        {/* Left: AI Branding & Matrix Status */}
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-sm border shadow-lg"
            style={{
              backgroundColor: `${cfg.primary}20`,
              borderColor: cfg.primary,
              color: cfg.primary,
              boxShadow: `0 0 12px ${cfg.primary}50`,
            }}
          >
            Z
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h1 className="text-base md:text-lg font-bold tracking-widest font-mono uppercase text-white">
                ZOYA // AI ASSISTANT
              </h1>
              <span
                className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase"
                style={{
                  color: cfg.primary,
                  borderColor: `${cfg.primary}50`,
                  backgroundColor: `${cfg.primary}15`,
                }}
              >
                {cfg.name}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-white/50">
              <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: cfg.primary }} />
              <span>STARK CORE ONLINE // ACTIVE INTERFACE</span>
            </div>
          </div>
        </div>

        {/* Right: Quick Action HUD Toggles */}
        <div className="flex items-center gap-2">
          {/* Terminal Console Toggle */}
          <button
            onClick={() => {
              sfx.playClick();
              setSystemState((s) => ({ ...s, terminalOpen: !s.terminalOpen }));
            }}
            className={`p-2 rounded-lg border font-mono text-xs flex items-center gap-1.5 transition-colors ${
              systemState.terminalOpen
                ? "bg-white/15 text-white"
                : "bg-white/5 text-white/70 hover:text-white"
            }`}
            style={{
              borderColor: systemState.terminalOpen ? cfg.primary : "rgba(255,255,255,0.1)",
            }}
            title="Toggle System Terminal"
          >
            <TerminalIcon size={15} style={{ color: cfg.primary }} />
            <span className="hidden sm:inline text-[11px]">TERMINAL</span>
          </button>

          {/* Notes Scratchpad Toggle */}
          <button
            onClick={() => {
              sfx.playClick();
              setShowNotesModal(true);
            }}
            className="p-2 rounded-lg border bg-white/5 text-white/70 hover:text-white border-white/10 transition-colors flex items-center gap-1.5"
            title="Open Protocol Notes"
          >
            <FileText size={15} style={{ color: cfg.primary }} />
            <span className="hidden sm:inline text-[11px]">NOTES ({systemState.notes.length})</span>
          </button>

          {/* Audio Mute Quick Toggle */}
          <button
            onClick={() => {
              sfx.playClick();
              setSystemState((s) => ({ ...s, isMuted: !s.isMuted }));
            }}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/10"
            title={systemState.isMuted ? "Unmute Audio" : "Mute Audio"}
          >
            {systemState.isMuted ? (
              <VolumeX size={15} className="text-red-400" />
            ) : (
              <Volume2 size={15} style={{ color: cfg.primary }} />
            )}
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => {
              if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
                setIsFullscreen(true);
              } else {
                document.exitFullscreen().catch(() => {});
                setIsFullscreen(false);
              }
              sfx.playClick();
            }}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/10"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
          </button>

          {/* Clear Chat History */}
          {messages.length > 0 && (
            <button
              onClick={() => {
                sfx.playClick();
                if (confirm("Reset conversation memory buffers?")) {
                  setMessages([]);
                  resetZoyaSession();
                  addLog("SYS", "CHAT BUFFER PURGED");
                }
              }}
              className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 hover:text-red-400 transition-colors border border-white/10"
              title="Clear Terminal Chat"
            >
              <Trash2 size={15} className="opacity-70" />
            </button>
          )}
        </div>
      </header>

      {/* ================= MAIN DASHBOARD BODY ================= */}
      <main className="flex-1 w-full flex flex-col lg:flex-row items-center justify-between p-3 md:p-6 gap-4 overflow-hidden z-10">
        {/* LEFT COLUMN: Telemetry HUD (Desktop visible, mobile collapsible) */}
        <div className="hidden lg:flex flex-col justify-center h-full z-10 shrink-0">
          <TelemetryHUD
            theme={systemState.theme}
            appState={appState}
            audioLevel={audioLevel}
          />
        </div>

        {/* CENTER COLUMN: Arc Reactor Core & Dynamic Holographic Dialogue */}
        <div className="flex-1 flex flex-col items-center justify-center relative w-full h-full max-w-2xl px-2">
          {/* Holographic Arc Reactor */}
          <div className="relative flex items-center justify-center my-auto">
            <ArcReactor
              state={appState}
              theme={systemState.theme}
              onClick={toggleListening}
              audioLevel={audioLevel}
            />
          </div>

          {/* Holographic Interactive Dialogue Bar (Latest interaction readout) */}
          <div className="w-full max-w-xl z-10 mt-2 mb-1">
            <AnimatePresence mode="wait">
              {latestMessage && (
                <motion.div
                  key={latestMessage.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="p-3.5 rounded-xl border backdrop-blur-xl shadow-2xl flex flex-col gap-1"
                  style={{
                    backgroundColor: "rgba(2, 7, 13, 0.85)",
                    borderColor: `${cfg.primary}40`,
                    boxShadow: `0 0 25px ${cfg.primary}20`,
                  }}
                >
                  <div className="flex items-center justify-between font-mono text-[10px]">
                    <span
                      className="font-bold uppercase tracking-wider flex items-center gap-1.5"
                      style={{ color: latestMessage.sender === "zoya" ? cfg.primary : "#c084fc" }}
                    >
                      <Activity size={11} />
                      {latestMessage.sender === "zoya" ? "ZOYA CORE RESPONSE" : "USER TRANSMISSION"}
                    </span>
                    <span className="text-white/40">{latestMessage.timestamp}</span>
                  </div>
                  <p className="text-sm md:text-base font-sans font-medium text-white/95 leading-relaxed">
                    {latestMessage.text}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* RIGHT COLUMN: System Control Panel (Desktop visible) */}
        <div className="hidden lg:flex flex-col justify-center h-full z-10 shrink-0">
          <SystemControlPanel
            systemState={systemState}
            onUpdateState={setSystemState}
            onTriggerCommand={handleCommand}
            onOpenNotes={() => setShowNotesModal(true)}
          />
        </div>
      </main>

      {/* ================= BOTTOM HUD CONTROLS ================= */}
      <footer
        className="w-full flex flex-col items-center justify-center pb-4 pt-2 px-4 md:px-8 z-20 shrink-0 gap-3 border-t backdrop-blur-md"
        style={{
          backgroundColor: "rgba(2, 7, 13, 0.9)",
          borderColor: `${cfg.primary}30`,
        }}
      >
        {/* Command Terminal Input Bar */}
        <form onSubmit={handleTextSubmit} className="w-full max-w-xl flex items-center gap-2">
          <div
            className="flex-1 flex items-center gap-2.5 px-4 py-2.5 rounded-full border backdrop-blur-lg bg-white/5 transition-all shadow-xl"
            style={{
              borderColor: `${cfg.primary}40`,
              boxShadow: `0 0 20px ${cfg.primary}15`,
            }}
          >
            <span className="font-mono text-xs font-bold" style={{ color: cfg.primary }}>
              ZOYA://
            </span>
            <input
              type="text"
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Command Zoya (e.g. 'volume 80%', 'red alert', 'diagnostics', 'open youtube', 'take note')..."
              className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/30 text-xs md:text-sm font-mono"
            />
            {appState === "processing" ? (
              <Loader2 size={16} className="animate-spin" style={{ color: cfg.primary }} />
            ) : (
              <button
                type="submit"
                disabled={!textInput.trim()}
                className="p-1.5 rounded-full hover:bg-white/10 disabled:opacity-30 transition-colors"
                style={{ color: cfg.primary }}
              >
                <Send size={15} />
              </button>
            )}
          </div>
        </form>

        {/* Center Primary Voice Command Button + Tactical Quick Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3">
          {/* Main Vocal Connection Button */}
          <button
            onClick={toggleListening}
            className={`
              relative flex items-center gap-2.5 px-6 py-2.5 rounded-full font-mono text-xs md:text-sm font-bold tracking-wider transition-all duration-300 shadow-2xl border
              ${
                isSessionActive
                  ? "bg-red-500/20 text-red-400 border-red-500 hover:bg-red-500/30 animate-pulse shadow-red-500/40"
                  : "hover:scale-105"
              }
            `}
            style={{
              backgroundColor: isSessionActive ? undefined : `${cfg.primary}20`,
              borderColor: isSessionActive ? undefined : cfg.primary,
              color: isSessionActive ? undefined : cfg.primary,
              boxShadow: isSessionActive ? undefined : `0 0 25px ${cfg.primary}40`,
            }}
          >
            {isSessionActive ? (
              <>
                <MicOff size={16} />
                <span>TERMINATE LINK</span>
              </>
            ) : (
              <>
                <Mic size={16} className="animate-pulse" />
                <span>START VOCAL LINK</span>
              </>
            )}
          </button>

          {/* Quick Voice Command Chips */}
          <button
            onClick={() => handleCommand("run system diagnostics")}
            className="px-2.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-[11px] font-mono text-white/80 transition-all flex items-center gap-1"
          >
            <ShieldAlert size={11} style={{ color: cfg.primary }} />
            Diagnostics
          </button>

          <button
            onClick={() => handleCommand("set volume to 80%")}
            className="px-2.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-[11px] font-mono text-white/80 transition-all flex items-center gap-1"
          >
            <Volume2 size={11} style={{ color: cfg.primary }} />
            Vol 80%
          </button>

          <button
            onClick={() => handleCommand("red alert")}
            className="px-2.5 py-1.5 rounded-full bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-[11px] font-mono text-red-400 transition-all flex items-center gap-1"
          >
            <Zap size={11} className="text-red-400" />
            Red Alert
          </button>

          <button
            onClick={() => handleCommand("open camera")}
            className="px-2.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-[11px] font-mono text-white/80 transition-all"
          >
            Optical HUD
          </button>

          <button
            onClick={() => handleCommand("open youtube")}
            className="px-2.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-[11px] font-mono text-white/80 transition-all"
          >
            YouTube
          </button>

          {/* Mobile-only toggle for System Control drawer/modal */}
          <div className="lg:hidden flex items-center gap-1.5">
            <button
              onClick={() => {
                sfx.playClick();
                setSystemState((s) => ({ ...s, terminalOpen: !s.terminalOpen }));
              }}
              className="p-1.5 rounded-lg border border-white/15 bg-white/5 text-white/80"
              title="Terminal"
            >
              <TerminalIcon size={14} />
            </button>
            <button
              onClick={() => {
                sfx.playClick();
                setShowNotesModal(true);
              }}
              className="p-1.5 rounded-lg border border-white/15 bg-white/5 text-white/80"
              title="Notes"
            >
              <FileText size={14} />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
