export type HudTheme = "cyan" | "red_alert" | "tactical_amber" | "matrix_green";

export type AppState = "idle" | "listening" | "processing" | "speaking";

export interface ChatMessage {
  id: string;
  sender: "user" | "zoya" | "system";
  text: string;
  timestamp?: string;
}

export interface SystemTelemetry {
  cpuLoad: number; // percentage
  ramUsage: number; // MB or percentage
  batteryLevel: number; // 0 - 100
  isCharging: boolean;
  pingMs: number;
  uptimeSeconds: number;
  securityStatus: "SECURE" | "ELEVATED" | "LOCKDOWN";
  audioLevel: number; // 0 - 100
}

export interface ActiveTimer {
  id: string;
  label: string;
  totalSeconds: number;
  remainingSeconds: number;
  active: boolean;
}

export interface SystemControlState {
  volume: number; // 0 - 100
  brightness: number; // 20 - 100
  isMuted: boolean;
  theme: HudTheme;
  cameraActive: boolean;
  terminalOpen: boolean;
  soundEffectsEnabled: boolean;
  notes: string[];
  activeTimers: ActiveTimer[];
}
