# Nayra Local Agent V5

Windows 11 local agent for Zoya. Start with `npm run agent` or `START_ZOYA.bat`.

Features: robust Win32 Unicode input, foreground focus, existing browser-tab discovery, YouTube play/pause/stop, screen-aware computer tasks, WhatsApp workflows, files/folders, website generation, reminders and persistent memory.

The agent binds to 127.0.0.1:3210 only. Do not expose this port publicly.
