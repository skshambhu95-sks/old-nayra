@echo off
curl -s http://127.0.0.1:3210/api/health
pause
