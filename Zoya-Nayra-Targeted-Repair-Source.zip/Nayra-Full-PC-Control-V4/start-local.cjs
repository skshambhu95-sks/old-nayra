const { spawn } = require("node:child_process");

function start(label, command, args) {
  const actual = process.platform === "win32" && command === "npm" ? "npm.cmd" : command;
  const child = spawn(actual, args, { stdio: "inherit", shell: false, cwd: process.cwd() });
  child.on("exit", (code) => console.log(`[${label}] exited with code ${code}`));
  return child;
}

console.log("\n=== ZOYA LOCAL WINDOWS 11 MODE ===");
console.log("Starting the local Windows control agent first...\n");
const agent = start("AGENT", "npm", ["run", "agent"]);
setTimeout(() => {
  console.log("Starting Zoya UI...\n");
  start("UI", "npm", ["run", "dev"]);
}, 1200);

function shutdown() {
  try { agent.kill(); } catch {}
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
