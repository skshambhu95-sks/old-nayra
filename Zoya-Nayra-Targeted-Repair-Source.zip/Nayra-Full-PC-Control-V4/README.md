# Nayra / Zoya Windows 11 Agent V5

This version keeps the existing Zoya UI and adds a local Windows agent.

## Start
1. Open the project folder.
2. Create `.env` from `.env.example` and set `GEMINI_API_KEY=...`.
3. Double-click `START_ZOYA.bat`.
4. Check `http://127.0.0.1:3210/api/health`.

## Important behavior
- Existing browser tabs are preferred. A new tab is not created by the local agent unless the user explicitly asks for one.
- YouTube commands search/use an existing YouTube tab and play/pause/stop there.
- Windows text input uses Win32 SendInput Unicode rather than flaky SendKeys.
- General computer tasks use screenshot -> AI plan -> one UI action -> screenshot verification loop.
- Chat history is kept in browser localStorage and is passed into a new voice session so mic off/on does not erase visible conversation context.
- Local persistent memory is stored under `%USERPROFILE%\\.nayra\\memory.json`.
- Reminders are stored under `%USERPROFILE%\\.nayra\\reminders.json`.

## Security
Destructive commands such as shutdown/restart/delete are intentionally available because this is a local agent for the owner's PC. Keep the agent bound to 127.0.0.1 and do not expose port 3210 to the public internet.
