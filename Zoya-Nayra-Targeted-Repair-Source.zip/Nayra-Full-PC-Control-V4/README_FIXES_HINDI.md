# Zoya/Nayra Stabilization — 21 October 2026

यह पुरानी working Zoya V5 के स्रोत पर आधारित targeted repair build है, नया Phase 1 नहीं।

## वास्तविक बदलाव
- Windows backend में Hindi spoken app names और `नोटपैड खोलो` जैसे verb-last commands की normalization.
- `नायरा क्रोम खोलो`, `नायरा नोटपैड खोलो`, `क्रोम में यूट्यूब खोलो` के लिए deterministic local routing.
- Chrome खोलते समय पहले मौजूदा process focus करने का प्रयास; YouTube उसी tab में navigate.
- Backend के AI text model को hardcoded 2.5 से available model discovery के आधार पर चुनना.
- Browser chat, TTS, live model को .env के जरिए configurable करना; Kore voice unchanged.
- Local PC-control API पर remote-origin CORS requests को reject करना.

## टेस्ट और सीमाएं
- यह build Windows 11 पर end-to-end tested नहीं है।
- npm dependency installation इस निर्माण वातावरण में समय सीमा पर रुक गई, इसलिए TypeScript/build checks पूरे नहीं हुए।
- Gemini API model access, microphone stability, screen control और arbitrary app focus को अभी verify करना जरूरी है।
- इस build को full working JARVIS कहना सही नहीं होगा।

## इंस्टॉल
1. ZIP अलग folder में extract करें; original backup रखें।
2. Node.js LTS install हो।
3. `.env.example` की copy `.env` बनाएं और GEMINI_API_KEY भरें।
4. `START_ZOYA.bat` चलाएं; दो terminal windows खुलनी चाहिए।
5. पहले http://127.0.0.1:3210/api/health जांचें, फिर http://127.0.0.1:3000 खोलें।
6. पहले text commands, फिर Kore voice commands जांचें।
7. असफलता पर दोनों terminal windows की error lines सुरक्षित रखें; API key न भेजें।

## टेस्ट क्रम
- नायरा नोटपैड खोलो
- नायरा कैलकुलेटर खोलो
- नायरा क्रोम खोलो
- क्रोम में यूट्यूब खोलो
- स्क्रीन पर क्या दिख रहा है

किसी भी वास्तविक file-delete, shutdown, WhatsApp message या money-related action से पहले सावधानी रखें।
